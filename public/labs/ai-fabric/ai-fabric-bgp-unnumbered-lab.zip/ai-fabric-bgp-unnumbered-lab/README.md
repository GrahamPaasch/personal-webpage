# AI-fabric lab: BGP unnumbered, ECMP and BFD on FRRouting

A free, self-hostable copy of the lab from Graham Paasch's video **"Build an AI-cluster fabric"**:
a 2-spine / 3-leaf L3 Clos running eBGP **unnumbered** on FRRouting 10.5.5 (no IP addresses on any
fabric link), ECMP across both spines, and the demo where one silent link failure costs ~75 packets
until one line of BFD config turns it into ~4.

Lesson (open in a browser): `lesson/index.html` · Hardware bill of materials: `lesson/bom.html`
Online: https://www.grahampaasch.com/labs/ai-fabric

```
        [spine1 AS65000]        [spine2 AS65000]        lo 10.0.0.1 / 10.0.0.2
          eth0 eth1 eth2          eth0 eth1 eth2
           |    |    |             |    |    |          fabric links: no IPv4 at all
        [leaf1] [leaf2] [leaf3]  (eth0 -> spine1, eth1 -> spine2, eth2 -> host)
        AS65101 AS65102 AS65103   lo 10.0.1.1-3
           |       |       |
          h1      h2      h3      172.16.{1,2,3}.10/24, gateway .1 on the leaf
```

## What's in the kit

| Path | What |
|---|---|
| `ai-fabric.clab.yml` | containerlab topology (stock upstream images) |
| `gns3/ai-fabric-baseline.gns3project` | GNS3 portable project, baseline state (3 leaves, BFD off) |
| `docker/frr/` | Dockerfile + start script for the GNS3 router image `ai-fabric-lab/frr:10.5.5` |
| `configs/` | every node's config: `*.frr.conf`, `h*.interfaces`, `sysctl.sh`, `daemons`, `vtysh.conf` |
| `scripts/` | containerlab helpers for the demo: `which-uplink.sh`, `link.sh` (suspend/resume a link) |
| `solutions/` | answers to the three exercises (exercise 1 includes a deployable 4-leaf topology) |
| `lesson/` | the full lesson page and the bill of materials |

## Requirements

- Linux with Docker (tested on Ubuntu 24.04, x86_64). containerlab also runs under WSL2 and on macOS via a Linux VM.
- **RAM:** 2 GB free is plenty. Measured: each FRR router ~60 MB, each host under 10 MB (under 400 MB total).
- **CPU:** 2 cores. Idle load is near zero; the `iperf3` step will use whatever you give it.
- **Disk:** about 1 GB for containerlab (FRR 195 MB + netshoot 630 MB), about 300 MB for GNS3 (FRR 195 MB + ipterm 110 MB).
- Option A: [containerlab](https://containerlab.dev/install/) (tested with 0.73).
- Option B: [GNS3](https://gns3.com) 2.2 with Docker support on the server/VM (tested with 2.2.56).

## Quickstart A: containerlab (one command)

```sh
cd ai-fabric-bgp-unnumbered-lab
sudo containerlab deploy -t ai-fabric.clab.yml
```

Give BGP ~10 seconds, then:

```sh
docker exec -it clab-ai-fabric-leaf1 vtysh -c 'show bgp summary'   # 2 neighbors, Established
docker exec -it clab-ai-fabric-leaf1 vtysh                          # router CLI
docker exec -it clab-ai-fabric-h1 bash                              # host shell (ping, iperf3, traceroute)
```

Tear down: `sudo containerlab destroy -t ai-fabric.clab.yml --cleanup`

Notes:
- `network-mode: none` keeps Docker's management interface out of the nodes, so interface names
  (`eth0`, `eth1`, `eth2`) match the GNS3 version and the lesson exactly.
- If deploy fails with *"subnet 172.20.20.0/24 ... overlaps an existing Docker network"*, another
  Docker network already uses containerlab's default management subnet. Add a `mgmt:` block with a
  free subnet under `name:` in the topology file, for example:
  `mgmt: {network: ai-fabric-mgmt, ipv4-subnet: 172.31.99.0/24, ipv6-subnet: "3fff:172:31:99::/64"}`
- The configs are bind-mounted from `configs/`. Changes you make in vtysh live until you destroy the lab;
  skip `write memory` here, since saving would try to edit the kit's own files. Redeploy to get back to baseline.
- Hosts are `nicolaka/netshoot`: its `traceroute` is BusyBox, so use `-p <port>` instead of `--sport`
  (see the demo script below).

## Quickstart B: GNS3

1. On the machine running your GNS3 server (or inside the GNS3 VM), build the router image:
   ```sh
   docker build -t ai-fabric-lab/frr:10.5.5 docker/frr
   ```
   It's upstream `quay.io/frrouting/frr:10.5.5` plus: routing daemons enabled, a start script that runs
   `/etc/frr/sysctl.sh` and then opens a bash console (type `vtysh` for the router CLI), and tcpdump/iperf3.
2. GNS3: **File > Import portable project** > `gns3/ai-fabric-baseline.gns3project`.
3. Start all nodes. Hosts use `gns3/ipterm`, which GNS3 pulls from Docker Hub on first start.
4. Open a console on leaf1, `vtysh`, `show bgp summary`.

The routers boot with their configs and kernel settings already applied. BFD is **off** (profile `FAST`
is defined but not attached), exactly where the demo starts. The spines have a spare `eth3` for exercise 1.

## Demo script (~15 minutes)

Commands are the same in both versions; containerlab equivalents for the GNS3 mouse actions are noted.

1. **No IPs on the fabric.** leaf1: `show interface brief` - eth0/eth1 have only an `fe80::` address.
2. **BGP by interface name.** `show bgp summary` (peers `spine1(eth0)`, `spine2(eth1)`), then
   `show bgp neighbors eth0` - peer is `fe80::...`, hold time 9 s / keepalive 3 s (`frr defaults datacenter`).
3. **ECMP.** `show bgp ipv4 unicast 172.16.3.0/24` (2 paths, both `multipath`), `show ip route 172.16.3.0/24`
   (2 next hops), and in bash `ip route show 172.16.3.0/24` (`nexthop via inet6` twice = RFC 8950).
   On spine2, the same prefix has exactly **one** path: same-ASN spines are valley-free (RFC 7938).
4. **Traffic really spreads.** h3: `iperf3 -s`; h1: `iperf3 -c 172.16.3.10 -P 8 -t 30`; watch
   `ip -s link show eth2` on both spines - both counters climb (tested: 10.27 GB vs 10.26 GB).
   Per-flow hashing: from h1, `traceroute -n -q1 -w1 -p 33434 172.16.3.10` vs `-p 34000` (netshoot) or
   `-U --sport=40001` vs `--sport=40003` (ipterm) - hop 2 flips between 10.0.0.1 and 10.0.0.2.
5. **Gray failure, no BFD.** h1: `ping -i 0.1 172.16.3.10`. Find the uplink the ping uses
   (GNS3: capture on leaf1's two uplinks; containerlab: `sudo scripts/which-uplink.sh`), then suspend it
   (GNS3: right-click link > Suspend; containerlab: `sudo scripts/link.sh suspend eth0|eth1`).
   Interfaces stay UP; leaf1's `show bgp summary` keeps the session Established for ~7-9 s until the hold
   timer fires. Ctrl-C the ping: **~60-90 lost** (tested: 75 in containerlab, 79 and 71 in GNS3).
   Resume the link (`sudo scripts/link.sh resume eth0|eth1`).
6. **Turn on BFD and repeat.** Paste into the bash consoles (`docker exec -it clab-ai-fabric-leaf1 bash`):
   ```sh
   # leaf1
   vtysh -c 'conf t' -c 'router bgp 65101' -c 'neighbor FABRIC bfd profile FAST' -c 'end'
   # spine1 AND spine2 (eth0 = the link to leaf1 on both)
   vtysh -c 'conf t' -c 'router bgp 65000' -c 'neighbor eth0 bfd profile FAST' -c 'end'
   # verify on leaf1: 2 peers "up"
   vtysh -c 'show bfd peers brief'
   ```
   Same failure again: **~3-4 lost** (tested: 3 in containerlab, 4 in GNS3). BFD peer `down`, session gone
   within a second, route down to one next hop. Resume: BFD up, BGP up, two next hops.
   Reset for another take: `no neighbor FABRIC bfd` (leaf1) / `no neighbor eth0 bfd` (spines). Removing BFD
   bounces BGP for ~1 s, so stop the ping first.

Why not just set 1-second BGP timers? Keepalives live in the routing process and get starved when the CPU
is busy; BFD is tiny, purpose-built, often hardware-offloaded, and tells every protocol at once.

## Exercises (answers in `solutions/` and in the lesson's "Show answer" boxes)

1. **Scale out with zero IP planning.** Add leaf4 (AS 65104, lo 10.0.1.4/32, h4 on 172.16.4.0/24) on
   spine eth3. *Answer:* leaf4 is leaf3 with four values changed, and each spine needs exactly one line:
   `neighbor eth3 interface peer-group FABRIC`. No IPs, no ASNs. (`solutions/exercise1/`, includes
   `ai-fabric-4leaf.clab.yml`.)
2. **Drain a spine with zero packet loss.** Prepend `65000 65000` outbound on spine2 with a route-map.
   *Answer:* leaves drop spine2 from ECMP because multipath only combines equal-length AS paths; it's
   lossless because it's make-before-break (spine2 keeps forwarding until the new path is installed).
   (`solutions/exercise2/`)
3. **Break the ASN design.** Move spine2 to AS 65001. *Answer:* spine2 now sees 3 paths to
   172.16.3.0/24 (the direct one plus two "valley" paths through other leaves and spine1); leaves need no
   change thanks to `remote-as external`; without `multipath-relax`, leaf1 loses ECMP because the two AS
   paths are no longer identical. (`solutions/exercise3/`)

## What was tested

- **containerlab 0.73 on Ubuntu 24.04:** deployed this exact folder: 12/12 BGP sessions Established,
  2-way ECMP in FRR and the kernel, valley-free single path on spine2, full host ping mesh, iperf3 split
  50/50 across spines, gray failure 75 lost without BFD vs 3 with BFD, exercises 1-3. Destroyed cleanly.
- **GNS3 2.2.56:** built the baseline project, restarted all nodes (configs and sysctls come back on their
  own), exported it, re-imported the export as a new project, started it and re-verified BGP, ECMP and pings.
  The BFD demo and all three exercises were run on camera on the original GNS3 lab.

## Credits

- [FRRouting](https://frrouting.org) - the routing stack (and the BGP daemon inside SONiC).
- [GNS3](https://gns3.com) - the lab in the video; `gns3/ipterm` host image.
- [containerlab](https://containerlab.dev) - the one-command version; [netshoot](https://github.com/nicolaka/netshoot) hosts.
- [Agent Standup](https://github.com/Atoll92/agent-standup) by Atoll92 - the live "video call" view of the
  Claude Code agent team that built and tested this lab on camera.
- References: RFC 7938 (BGP in large-scale data centers), RFC 8950 (IPv4 NLRI with IPv6 next hop),
  RFC 5880/5881 (BFD), FRR docs (BGP unnumbered, `frr defaults datacenter`, BFD profiles).

## License

MIT for the kit (see `LICENSE`). Third-party software keeps its own license.
