#!/bin/bash
# Lab FRR start: kernel prep, start FRR daemons under watchfrr, then give the console a shell.
sysctl -qw net.ipv4.ip_forward=1 net.ipv6.conf.all.forwarding=1 2>/dev/null || true
[ -f /etc/frr/sysctl.sh ] && sh /etc/frr/sysctl.sh >/dev/null 2>&1
[ -s /etc/frr/frr.conf ] || printf "frr defaults datacenter\nhostname %s\nservice integrated-vtysh-config\n!\n" "$(hostname)" > /etc/frr/frr.conf
chown -R frr:frr /etc/frr 2>/dev/null || true
/usr/lib/frr/frrinit.sh start >/dev/null 2>&1
echo "FRR $(vtysh -c "show version" 2>/dev/null | head -1 | cut -c1-40) ready - type vtysh for the router CLI"
exec /bin/bash -l
