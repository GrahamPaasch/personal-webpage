Exercise 1 - scale out with zero IP planning (leaf4 + h4)

leaf4.frr.conf     = leaf3's config with 4 values changed (hostname, ASN 65104, lo 10.0.1.4, eth2 172.16.4.1/24)
h4.interfaces      = h4 172.16.4.10/24 gw 172.16.4.1
spine1/2.frr.conf  = baseline + ONE line:  neighbor eth3 interface peer-group FABRIC
ai-fabric-4leaf.clab.yml = the whole 4-leaf fabric for containerlab:
    sudo containerlab deploy -t ai-fabric-4leaf.clab.yml      (run from this folder)

GNS3: the spines in the project already have a spare eth3. Right-click leaf3 > Duplicate and rename the copy
leaf4 (same image, adapters and /etc/frr folder, including sysctl.sh); do the same with h3 -> h4. Cable
leaf4 eth0 - spine1 eth3, leaf4 eth1 - spine2 eth3, leaf4 eth2 - h4 eth0. Edit h4's network configuration
(h4.interfaces). Start them, then in leaf4's console paste leaf4.frr.conf over /etc/frr/frr.conf
(cat > /etc/frr/frr.conf ... Ctrl-D, then /usr/lib/frr/frrinit.sh restart).
On each spine: vtysh -c 'conf t' -c 'router bgp 65000' -c 'neighbor eth3 interface peer-group FABRIC'

Success: h1 pings 172.16.4.10; leaf1 "show ip route 172.16.4.0/24" has two fe80:: next hops (eth0 + eth1).
Tested on containerlab: spines 4/4 Established, leaf4 2/2, leaf1 2-way ECMP to 172.16.4.0/24, h1 -> h4 3/3.
