#!/bin/sh
# Containerlab stand-in for GNS3's "Suspend link": drop 100% of packets on a leaf1 uplink,
# in both directions, while both interfaces stay UP (a "gray" failure, like a dying optic).
# Usage: sudo scripts/link.sh suspend|resume eth0|eth1 [lab-name]
#   eth0 = leaf1 <-> spine1 (spine1 side: eth0)    eth1 = leaf1 <-> spine2 (spine2 side: eth0)
set -e
ACTION=$1; IF=$2; LAB=${3:-ai-fabric}
case "$IF" in eth0) PEER=spine1 ;; eth1) PEER=spine2 ;; *) echo "usage: $0 suspend|resume eth0|eth1 [lab]"; exit 1 ;; esac
case "$ACTION" in
  suspend) LOSS=100 ;;
  resume)  LOSS=0 ;;
  *) echo "usage: $0 suspend|resume eth0|eth1 [lab]"; exit 1 ;;
esac
containerlab tools netem set -n clab-$LAB-leaf1 -i $IF --loss $LOSS >/dev/null
containerlab tools netem set -n clab-$LAB-$PEER -i eth0 --loss $LOSS >/dev/null
echo "$ACTION: leaf1 $IF <-> $PEER eth0 (loss ${LOSS}%). Interfaces stay up:"
docker exec clab-$LAB-leaf1 ip -br link show $IF
