#!/bin/sh
# Which leaf1 uplink is the h1 -> h3 ping using? (containerlab version)
# Run while `ping -i 0.1 172.16.3.10` is running on h1.
# Usage: sudo scripts/which-uplink.sh [lab-name]      (default lab name: ai-fabric)
LAB=${1:-ai-fabric}; C=clab-$LAB-leaf1
a0=$(docker exec $C cat /sys/class/net/eth0/statistics/tx_packets); a1=$(docker exec $C cat /sys/class/net/eth1/statistics/tx_packets)
sleep 2
b0=$(docker exec $C cat /sys/class/net/eth0/statistics/tx_packets); b1=$(docker exec $C cat /sys/class/net/eth1/statistics/tx_packets)
d0=$((b0-a0)); d1=$((b1-a1))
echo "leaf1 eth0 (to spine1): +$d0 packets in 2 s"
echo "leaf1 eth1 (to spine2): +$d1 packets in 2 s"
if [ $d0 -gt $d1 ]; then echo "=> the ping rides eth0. Suspend it with: sudo scripts/link.sh suspend eth0 $LAB"
else echo "=> the ping rides eth1. Suspend it with: sudo scripts/link.sh suspend eth1 $LAB"; fi
