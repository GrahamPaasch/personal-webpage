#!/usr/bin/env python3
"""pingstats.py FILE [LABEL]: read the output of `ping -n -D -i 0.01 ...` and print what the outage cost.

lost  = icmp_seq numbers that never got a reply (QUINN's method on camera)
gap   = the biggest hole between two consecutive replies, from the -D timestamps, in ms.
        At 100 pps each lost packet is ~10 ms, but the gap is the honest number: it also counts
        the packet in flight when the path broke and the time to the next send after the fix.
"""
import re, sys

path = sys.argv[1]
label = sys.argv[2] if len(sys.argv) > 2 else path
replies = []                                   # (timestamp, seq)
tx = rx = None
for line in open(path, errors="replace"):
    m = re.search(r"^\[(\d+\.\d+)\].*icmp_seq=(\d+)", line)
    if m and "bytes from" in line:
        replies.append((float(m.group(1)), int(m.group(2))))
    m = re.search(r"(\d+) packets transmitted, (\d+) (?:packets )?received", line)
    if m:
        tx, rx = int(m.group(1)), int(m.group(2))
if not replies:
    print(f"{label}: no replies at all ({tx} sent)")
    sys.exit(0)
seqs = sorted({s for _, s in replies})
lost = (tx - rx) if tx is not None else (seqs[-1] - seqs[0] + 1 - len(seqs))
best = (0.0, None, None)
for (t0, s0), (t1, s1) in zip(replies, replies[1:]):
    if t1 - t0 > best[0]:
        best = (t1 - t0, s0, s1)
gap_ms, before, after = best[0] * 1000, best[1], best[2]
print(f"{label}: {tx} sent, {rx} replies, {lost} lost; biggest reply gap {gap_ms:.0f} ms "
      f"(last reply before it: icmp_seq {before}, first after: icmp_seq {after})")
