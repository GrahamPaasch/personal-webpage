# SRv6 no-routing lab: "OpenAI turned BGP off"

A free, self-hostable copy of the lab from episode 3 of Graham Paasch's series **"AI Agents Build the Lab"**.
It's the same 2-spine / 3-leaf / 3-host Clos as episodes 1 and 2, but this time **no routing protocol runs in
the fabric**. No BGP, no OSPF, no IS-IS, no BFD, no neighbors, no hellos. The switches hold a small static
**SRv6 uSID** table ("shift my 16 bits off the front, forward on the next 16"). The **host** writes the whole
path into the IPv6 destination address, sprays flows across both spines, and when a path dies the host
stops using it. That's the idea behind OpenAI's **MRC** (Multipath Reliable Connection) fabric, shrunk to a
laptop-sized lab.

Lesson (open in a browser): `lesson/index.html`
Online: https://www.grahampaasch.com/labs/srv6-no-routing (episode 2: https://www.grahampaasch.com/labs/bgp-vs-ospf)

```
          [spine1  uN fcbb:bb00:100::/48]        [spine2  uN fcbb:bb00:200::/48]
           eth0   eth1   eth2                      eth0   eth1   eth2
            |      |      |                         |      |      |
   [leaf1 fcbb:bb00:1::/48]  [leaf2 fcbb:bb00:2::/48]  [leaf3 fcbb:bb00:3::/48]   eth0 -> spine1, eth1 -> spine2
            | eth2                 |                        |                     eth2 -> host
   h1 172.16.1.10            h2 172.16.2.10           h3 172.16.3.10              (IPv6 fd00:a:N::10, gw fd00:a:N::1)

   path = ONE address:  fcbb:bb00:<spine>:<leaf>:fe00::   e.g. h1 -> h3 via spine2 = fcbb:bb00:200:3:fe00::
   "link 2" = leaf1 eth1 <-> spine2 eth0: the link the failure test breaks (same link as every episode)
```

## The commands

```
sudo ./lab.sh up      # build 5 switches + 3 hosts and wait until they forward, then run every check (~15 s)
sudo ./lab.sh check   # (1) no routing daemons / nothing on TCP 179  (2) SID tables  (3) both planes ping  (4) spray
sudo ./lab.sh fail    # break link 2 for 10 s with the host agent OFF, then again with it ON; print lost pings + ms
sudo ./lab.sh xray    # capture h1 -> h3 pings on both planes: the path is written in the packet
sudo ./lab.sh down    # destroy the lab and clean up
```

More: `sudo ./lab.sh fail off|on [SECONDS]` (one case only), `sudo ./lab.sh agent start|stop|status`
(run the host path agent by hand), `sudo ./lab.sh link suspend|resume` (break/repair link 2 by hand).
`sudo make up` / `check` / `fail` / `xray` / `down` do the same thing.

## What's in the kit

| Path | What |
|---|---|
| `lab.sh`, `Makefile` | up / check / fail / xray / agent / link / down |
| `srv6.clab.yml` | the containerlab topology (lab name `srv6`, containers `clab-srv6-<node>`) |
| `configs/leafN.conf`, `spineM.conf` | the ENTIRE switch config: interface addresses + 2 or 3 `ipv6 route` lines |
| `configs/daemons` | FRR daemons: only zebra, staticd, mgmtd. bgpd, ospfd, isisd, bfdd and the rest = no |
| `configs/srv6.sh` | the SIDs, in the kernel with iproute2: uN (`End flavors next-csid`) on dummy `sr0`, End.DX4 decap on leaves |
| `configs/path-agent.sh` | the host path agent (~45 lines of bash): probes every (leaf, plane) at 100/s, 3 misses = move off that plane |
| `configs/host.sh` | host boot: addresses, the IPv6 gateway, the agent's routes and rules (agent itself stays off) |
| `scripts/pingstats.py` | reads `ping -D` output: lost pings, biggest reply gap in ms, and the icmp_seq on each side of it |
| `solutions/exercise{1,2,3}/` | `answer.txt` + `run.sh` that reproduces each answer and then undoes it |
| `lesson/index.html` | the full lesson, with the numbers measured on camera |

## Requirements

- Linux with Docker (tested on Ubuntu 24.04, kernel 6.8, x86_64). The uSID "next-csid" flavor needs a kernel
  with SRv6 and NEXT-C-SID support (6.3 or newer, built in on Ubuntu's stock kernels). WSL2's kernel may lack SRv6.
- [containerlab](https://containerlab.dev/install/) (tested with 0.73) and `python3` (standard library only).
- **RAM:** under 300 MB for all 8 containers. **CPU:** 2 cores; it idles near zero (the agent's probes are 400 pings/s per host while it runs).
- **Disk:** about 850 MB for the two images: `quay.io/frrouting/frr:10.5.5` (195 MB) and `nicolaka/netshoot` (630 MB).
  containerlab pulls them on the first `up`. `lab.sh xray` and the exercises also run short-lived netshoot containers
  attached to a switch's network namespace (to use tcpdump, which the FRR image doesn't have).
- Root (`sudo`), because containerlab and `docker exec` need it.

The topology gives containerlab's (unused) management bridge its own subnet, 172.31.253.0/24, so it doesn't collide
with Docker's common 172.20.0.0/16. If it clashes with something on your machine, edit the `mgmt:` block in `srv6.clab.yml`.

## Quickstart

```
$ unzip srv6-no-routing-lab.zip && cd srv6-no-routing-lab
$ sudo ./lab.sh up
...
[1] No routing protocol in the fabric
  PASS spine1  running: mgmtd staticd watchfrr zebra | routing daemons: none | TCP 179 listeners: 0 | router/neighbor config lines: 0
  ...
[2] SRv6 uSID table (kernel seg6local SIDs, static /48s from FRR staticd)
  PASS spine1  1 SID(s) (uN), 3 static fcbb /48 routes (installed by FRR staticd)
  PASS leaf1   2 SID(s) (uN + End.DX4), 2 static fcbb /48 routes (installed by FRR staticd)
  ...
[3] h1 -> h3 on each plane (pinned with ping -m 1 / -m 2), counted on the spines' links to leaf3
  PASS plane 1: 10/10 replies (avg 0.083 ms), path fcbb:bb00:100:3:fe00::  spine1 eth2 +10, spine2 eth2 +0
  PASS plane 2: 10/10 replies (avg 0.088 ms), path fcbb:bb00:200:3:fe00::  spine1 eth2 +0, spine2 eth2 +10
  PASS full mesh: 12/12 (6 host pairs x 2 planes)
[4] Spray: 1000 new UDP flows h1 -> h3, unpinned (main table = ECMP over both planes, per-flow hash)
  PASS leaf1 sent 520 via spine1 (eth0) / 480 via spine2 (eth1); h3 received 1000 of 1000

ALL CHECKS PASSED: traffic flows on both planes and nothing in the fabric runs a routing protocol
```

Poke around:

```
docker exec -it clab-srv6-spine1 vtysh     # show running-config  (interfaces + 3 ipv6 routes, that's all)
docker exec clab-srv6-spine1 ip -6 route   # the uN SID: fcbb:bb00:100::/48 encap seg6local action End flavors next-csid
docker exec -it clab-srv6-h1 bash          # ip route show 172.16.3.0/24   (two paths, the host wrote both)
                                           # ping -m 1 172.16.3.10 (plane 1 = spine1)   ping -m 2 ... (plane 2 = spine2)
```

How a packet moves (h1 -> h3 via spine2): h1 wraps the IPv4 packet in IPv6 with destination
`fcbb:bb00:200:3:fe00::`. leaf1 just forwards it (static /48 to spine2). spine2 matches its uN `fcbb:bb00:200::/48`,
shifts its 16 bits out (the "ticket punch") so the address becomes `fcbb:bb00:3:fe00::`, and forwards on its static
/48 to leaf3. leaf3 matches `fcbb:bb00:3:fe00::/64` = End.DX4: strip the IPv6 header, hand the IPv4 packet to h3.
`sudo ./lab.sh xray` shows exactly that from tcpdump inside the switches.

## The failure test

`sudo ./lab.sh fail` pings h1 -> h3 at 100 per second with `ping -m 2` (a flow pinned on spine2, so it crosses
link 2), breaks link 2 for 10 s, and repairs it. Twice: first with the host agent **off**, then **on** (started on
all three hosts; the return path is the far host's choice). "Break" means 100% packet loss on both ends with
`containerlab tools netem`, while both interfaces stay **up**, like GNS3's *Suspend link* in the video: no switch
gets a "link down" hint, and nothing in the fabric is listening anyway. It also fires 1000 new UDP flows during the
failure and counts how many reach h3.

Kit run on containerlab (Ubuntu 24.04, 10/19/2026):

```
=== link 2 failure, host agent OFF ===
  1 s into the failure, h1 table 2 (the pinned flow): fcbb:bb00:200:3:fe00::      <- still pointing into the dead link
  spray during the failure (1000 new UDP flows h1->h3): h3 received ~500 of 1000  <- every flow hashed onto spine2 is gone
  RESULT agent off: 1600 sent, 733 replies, 867 lost; biggest reply gap 9563 ms   <- the whole outage, until the repair

=== link 2 failure, host agent ON ===
  agent logs:
    h1 04:18:08.644 leaf3 plane2 DOWN after 3 misses -> moved to other plane
    h3 04:18:08.646 leaf1 plane2 DOWN after 3 misses -> moved to other plane
    ...
  1 s into the failure, h1 table 2 (the pinned flow): fcbb:bb00:100:3:fe00::      <- the host rewrote the path
  RESULT agent on: 1600 sent, 1595 replies, 5 lost; biggest reply gap 68 ms (last reply before it: icmp_seq 271, first after: icmp_seq 277)
```

Without the agent the loss never stops on its own: nobody in the fabric is listening, so a static fabric can't heal.
With the agent: **5 lost pings, a ~70 ms reply gap**, and no switch did anything. Episode 2's eBGP twin lost **6 to 9
seconds** on this same link (hold timer 9 s), so that's about 100 times faster. Real MRC NICs react in tens of
microseconds.

Reading the numbers: at 100 pps each lost ping is ~10 ms, but "lost x 10 ms" undercounts. The honest number is the
biggest gap between two replies (from `ping -D` timestamps), which also counts the packet in flight when the path
broke. On camera (GNS3): 5-6 lost and a 66-77 ms gap with the agent; 918 lost / 10.11 s without it.
Tuning knob: `INT=0.005 MISS=3` in `path-agent.sh`'s environment halves detection time (twice the probe traffic).

## Exercises (answers in `solutions/` and in the lesson's "Answer" boxes)

1. **Add a third stop.** Make h1 -> h3 traffic visit leaf1's own uN explicitly. What's the address, and what does leaf1 do?
2. **Who notices a dead spine1-leaf3 link?** Break spine1 eth2 <-> leaf3 eth0 with the agents running.
   Which hosts move traffic, and which don't?
3. **Drop the header.** Change one table-1 route to `mode encap.red` and capture again. What disappears, and why
   does it still work?

Each `solutions/exerciseN/run.sh` reproduces the answer and undoes it.

## Honest: what this lab can't reproduce

MRC runs in the NIC, per **packet** across hundreds of paths, reacts in tens of microseconds, with RDMA (RoCEv2),
packet trimming on congestion instead of PFC, and per-path congestion control. This lab has none of that: no RDMA,
no trimming, per-**flow** hashing (Linux multipath), and a bash loop polling at 100 Hz. Same idea, a much slower
clock. And the trade-off is real: the fabric can't heal itself, every host must. BGP still lives at the edge and in
the backbone.

## Notes and gotchas

- **Static routes are still routing.** The routing moved out of the switches into the hosts. What's gone is the
  distributed protocol: no switch talks to any other switch.
- SIDs live on a dummy `sr0`, not `lo`: seg6local routes on `lo` silently drop (Ip6InNoRoutes climbs, nothing logged).
- FRR's own staticd SRv6 SIDs work for uN, but its uDT4 in the default VRF is rejected by kernel 6.8 (needs a VRF) and
  it has no DX4, so `srv6.sh` installs the SIDs with plain iproute2. They're kernel state: if you restart a switch
  container, re-run `sh /etc/frr/srv6.sh <usid> [leaf]` inside it (see the `exec:` lines in `srv6.clab.yml`).
- ICMP has no ports, so an unmarked ping always hashes to one plane. That's why the measured flow is pinned with
  `ping -m 2` (fwmark 2 -> table 2 = "a flow on spine2"). Unmarked flows spray per flow (main table, ECMP).
- Measure at `-i 0.01` and count missing icmp_seq. At `-i 0.001` iputils ping backs off while replies are missing.
- Start the agent on ALL hosts. h1 alone fixes only half the round trip.
- `SETUP_ONLY=1` is an environment variable, not an argument.
- Kit fixes vs. the on-camera script: `path-agent.sh`'s `spray()` now uses local variables (before, it overwrote
  the caller's plane number, so a plane-1 failure was logged as "plane2" and its recovery never fired; the on-camera
  failure was on plane 2, so the video wasn't affected), and log timestamps use bash's `EPOCHREALTIME` (UTC, ms)
  because netshoot's busybox `date` has no `%N`.

## Clean up

```
sudo ./lab.sh down     # destroys all 8 containers and the lab's management bridge
docker rmi quay.io/frrouting/frr:10.5.5 nicolaka/netshoot:latest     # optional: free the ~850 MB of images
```

## Credits and license

Built and tested by a team of Claude Code agents run by Graham Paasch (how the team works:
https://www.grahampaasch.com/cadence). Sources: OpenAI's MRC post, arXiv 2605.04333 "Resilient AI Supercomputer
Networking using MRC and SRv6", IETF draft-filsfils-srv6ops-srv6-ai-backend (links in the lesson).
MIT licensed (see `LICENSE`). FRRouting is GPLv2 and is pulled as an image, not redistributed here.
