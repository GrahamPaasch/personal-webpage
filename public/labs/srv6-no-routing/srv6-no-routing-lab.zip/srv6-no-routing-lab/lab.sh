#!/usr/bin/env bash
# Episode 3 lab: "OpenAI turned BGP off". A 2-spine / 3-leaf / 3-host SRv6 uSID fabric with NO routing protocol.
#
#   sudo ./lab.sh up                 build the fabric + hosts and wait until it forwards (about 30 s)
#   sudo ./lab.sh check              prove it: no routing daemons / nothing on TCP 179, both planes ping, spray splits
#   sudo ./lab.sh fail [off|on|both] [HOLD]   break link 2 for HOLD s (default 10) with the host agent OFF and/or ON
#   sudo ./lab.sh agent start|stop|status     run / stop / inspect the host path agent on h1-h3
#   sudo ./lab.sh link suspend|resume         break / repair link 2 (leaf1 eth1 <-> spine2 eth0) by hand
#   sudo ./lab.sh xray               capture h1->h3 pings on both planes: the path is written in the packet
#   sudo ./lab.sh down               destroy the lab and clean up
#
# Needs: Linux (kernel 6.8 tested; SRv6 uSID "next-csid" needs 6.3+), Docker, containerlab, python3.
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
LAB=srv6
SW="spine1 spine2 leaf1 leaf2 leaf3"
declare -A HARGS=([h1]="1 2 3" [h2]="2 1 3" [h3]="3 1 2")
LINK2="leaf1:eth1 spine2:eth0"

[ "$(id -u)" -eq 0 ] || { echo "run with sudo (containerlab and docker need root): sudo $0 $*"; exit 1; }
for b in docker containerlab python3; do command -v $b >/dev/null || { echo "missing: $b (see README prerequisites)"; exit 1; }; done

c()   { local n=$1; shift; docker exec clab-$LAB-$n "$@"; }
cnt() { c "$1" cat /sys/class/net/$2/statistics/tx_packets; }
FAILS=0
pass() { echo "  PASS $*"; }
fail() { echo "  FAIL $*"; FAILS=$((FAILS + 1)); }

link() { # suspend|resume [nodeA:if nodeB:if] : 100% loss on both ends, interfaces stay UP (like GNS3 "Suspend")
  local loss word ends=${2:-$LINK2}; [ "$1" = suspend ] && { loss=100; word=suspended; } || { loss=0; word=resumed; }
  local pids=""
  for e in $ends; do containerlab tools netem set -n clab-$LAB-${e%%:*} -i ${e#*:} --loss $loss >/dev/null & pids="$pids $!"; done
  wait $pids
  echo "$(date -u +%T.%3N) UTC link ${ends/ / <-> } ${word} (loss ${loss}%, carrier stays up, no switch notices)"
}

agent() {
  case "$1" in
    start)
      for h in h1 h2 h3; do
        c $h sh -c 'mkdir -p /run/path-agent; : > /run/path-agent/log'
        docker exec -d clab-$LAB-$h bash /root/path-agent.sh ${HARGS[$h]}
      done
      sleep 1.5
      for h in h1 h2 h3; do echo "  $h: $(c $h tail -1 /run/path-agent/log)"; done ;;
    stop)
      for h in h1 h2 h3; do
        c $h sh -c 'pkill -f "[p]ath-agent.sh"; pkill -x ping; true'
        c $h env SETUP_ONLY=1 bash /root/path-agent.sh ${HARGS[$h]}     # back to: both planes, agent off
      done
      echo "  agents stopped; routes reset to spray over both planes" ;;
    status)
      for h in h1 h2 h3; do
        echo "== $h  (agent $(c $h sh -c 'pgrep -f "[p]ath-agent.sh" >/dev/null && echo RUNNING || echo off'))"
        c $h sh -c 'tail -5 /run/path-agent/log 2>/dev/null; true'
        for L in ${HARGS[$h]#* }; do c $h ip route show 172.16.$L.0/24; done
      done ;;
    *) echo "usage: $0 agent start|stop|status"; exit 1 ;;
  esac
}

wait_ready() { # until h1 reaches h3 on both planes (static routes need the links up first)
  for i in $(seq 1 ${1:-90}); do
    if c h1 ping -c1 -W1 -m 1 172.16.3.10 >/dev/null 2>&1 && c h1 ping -c1 -W1 -m 2 172.16.3.10 >/dev/null 2>&1; then
      echo "fabric forwarding after ~${i}s"; return 0; fi
    sleep 1
  done
  echo "fabric did not come up in ${1:-90}s"; return 1
}

spray() { # 1000 new UDP flows h1 -> h3 (each echo = new source port = new flow); prints leaf1 eth0/eth1 tx deltas
  # also prints how many reached h3: nothing listens on UDP 9 there, so each arrival bumps h3's Udp NoPorts counter
  local b0 b1 r0
  noports() { c h3 awk '/^Udp:/ { if (h) print $3; h = 1 }' /proc/net/snmp; }
  b0=$(cnt leaf1 eth0); b1=$(cnt leaf1 eth1); r0=$(noports)
  c h1 bash -c 'for i in $(seq 1000); do echo x > /dev/udp/172.16.3.10/9; done'
  sleep 0.3
  echo "$(( $(cnt leaf1 eth0) - b0 )) $(( $(cnt leaf1 eth1) - b1 )) $(( $(noports) - r0 ))"
}

check() {
  echo "[1] No routing protocol in the fabric"
  for s in $SW; do
    procs=$(c $s sh -c 'cat /proc/[0-9]*/comm 2>/dev/null; true' | sort -u | tr '\n' ' ')
    bad=$(echo "$procs" | tr ' ' '\n' | grep -E '^(bgpd|ospfd|ospf6d|isisd|bfdd|ripd|ripngd|eigrpd|ldpd|pimd|babeld|fabricd|vrrpd)$' | tr '\n' ' ' || true)
    frr=$(echo "$procs" | tr ' ' '\n' | grep -E '^(zebra|staticd|mgmtd|watchfrr)$' | tr '\n' ' ' || true)
    l179=$(c $s ss -Htln 'sport = :179' | wc -l)
    rtr=$(c $s vtysh -c 'show running-config' | grep -cE '^ *(router |neighbor )' || true)
    if [ -z "$bad" ] && [ "$l179" -eq 0 ] && [ "$rtr" -eq 0 ]; then
      pass "$(printf '%-7s' $s) running: ${frr}| routing daemons: none | TCP 179 listeners: 0 | router/neighbor config lines: 0"
    else fail "$s routing daemons: '${bad}' TCP179=$l179 router-lines=$rtr"; fi
  done
  echo "[2] SRv6 uSID table (kernel seg6local SIDs, static /48s from FRR staticd)"
  for s in $SW; do
    sids=$(c $s ip -6 route show | grep -c seg6local || true)
    st=$(c $s ip -6 route show | grep '^fcbb' | grep -c 'proto 196' || true)
    want=2; [ "${s#spine}" != "$s" ] && want=1
    [ "$sids" -eq $want ] && pass "$(printf '%-7s' $s) $sids SID(s) ($( [ $want = 1 ] && echo 'uN' || echo 'uN + End.DX4')), $st static fcbb /48 routes (installed by FRR staticd)" \
                          || fail "$s has $sids seg6local SIDs (want $want)"
  done
  echo "[3] h1 -> h3 on each plane (pinned with ping -m 1 / -m 2), counted on the spines' links to leaf3"
  for P in 1 2; do
    a1=$(cnt spine1 eth2); a2=$(cnt spine2 eth2)
    out=$(c h1 ping -n -q -c 10 -i 0.05 -W 1 -m $P 172.16.3.10 2>&1 || true)
    d1=$(( $(cnt spine1 eth2) - a1 )); d2=$(( $(cnt spine2 eth2) - a2 ))
    rx=$(echo "$out" | grep -Eo '[0-9]+ received' | awk '{print $1}'); rtt=$(echo "$out" | grep -Eo '= [0-9.]+/[0-9.]+' | cut -d/ -f2)
    sid=$(c h1 ip route show 172.16.3.0/24 table $P | grep -Eo 'segs 1 \[ [^ ]+' | awk '{print $4}')
    [ "${rx:-0}" -eq 10 ] && pass "plane $P: 10/10 replies (avg ${rtt} ms), path ${sid}  spine1 eth2 +$d1, spine2 eth2 +$d2" \
                          || fail "plane $P: ${rx:-0}/10 replies"
  done
  ok=0; tot=0
  for pr in "1 2" "1 3" "2 1" "2 3" "3 1" "3 2"; do set -- $pr; for P in 1 2; do
    tot=$((tot + 1)); c h$1 ping -q -c 2 -i 0.1 -W 1 -m $P 172.16.$2.10 >/dev/null 2>&1 && ok=$((ok + 1)) || true
  done; done
  [ $ok -eq $tot ] && pass "full mesh: $ok/$tot (6 host pairs x 2 planes)" || fail "full mesh: $ok/$tot"
  echo "[4] Spray: 1000 new UDP flows h1 -> h3, unpinned (main table = ECMP over both planes, per-flow hash)"
  read -r s1 s2 r < <(spray)
  [ $s1 -ge 350 ] && [ $s2 -ge 350 ] && pass "leaf1 sent $s1 via spine1 (eth0) / $s2 via spine2 (eth1); h3 received $r of 1000" \
                                     || fail "spray $s1 / $s2 (expected roughly half each)"
  echo
  [ $FAILS -eq 0 ] && echo "ALL CHECKS PASSED: traffic flows on both planes and nothing in the fabric runs a routing protocol" \
                   || { echo "$FAILS CHECK(S) FAILED"; return 1; }
}

failtest() { # $1 = off|on, $2 = HOLD seconds
  local mode=$1 HOLD=$2 LEAD=3 SETTLE=3 TMP N
  N=$(( (LEAD + HOLD + SETTLE) * 100 )); TMP=$(mktemp -d)
  echo "=== link 2 failure, host agent ${mode^^} ==="
  [ $mode = on ] && agent start
  echo "h1: ping -n -D -i 0.01 -m 2 172.16.3.10 (a flow the host put on spine2, 100 pps = 10 ms per packet), $N pings"
  docker exec clab-$LAB-h1 ping -n -D -i 0.01 -W 1 -c $N -m 2 172.16.3.10 > $TMP/ping.txt 2>&1 &
  local pid=$!
  sleep $LEAD
  link suspend
  sleep 1
  echo "  1 s into the failure, h1 table 2 (the pinned flow): $(c h1 ip route show 172.16.3.0/24 table 2 | grep -Eo 'segs 1 \[ [^ ]+' | awk '{print $4}')"
  echo "  1 s into the failure, h1 main table (spray):       $(c h1 ip route show 172.16.3.0/24 | grep -Eo 'segs 1 \[ [^ ]+' | awk '{print $4}' | tr '\n' ' ')"
  local t0=$SECONDS s1 s2 r; read -r s1 s2 r < <(spray)
  echo "  spray during the failure (1000 new UDP flows h1->h3): h3 received $r of 1000; leaf1 tx +$s1 on eth0 (spine1), +$s2 on eth1 (spine2)"
  echo "    (eth1 counts nothing while link 2 is broken: the netem loss drops packets before they're counted; with the agent on, eth0 also carries its probes)"
  sleep $(( HOLD - 1 - (SECONDS - t0) > 0 ? HOLD - 1 - (SECONDS - t0) : 0 ))
  link resume
  wait $pid || true
  if [ $mode = on ]; then
    sleep 1
    echo "  agent logs:"; for h in h1 h2 h3; do c $h sh -c 'grep -E "DOWN|UP" /run/path-agent/log' | sed "s/^/    $h /"; done
    agent stop
  fi
  python3 scripts/pingstats.py $TMP/ping.txt "  RESULT agent $mode"
  cp $TMP/ping.txt "${SNAP_DIR:-/tmp}/srv6-fail-$mode.txt"; rm -rf "$TMP"
  echo
}

xray() {
  local T; T=$(mktemp -d)
  echo "capturing h1 -> h3 pings on both planes (ping -m 1 = via spine1, ping -m 2 = via spine2)..."
  cap() { docker run --rm --net container:clab-$LAB-$1 nicolaka/netshoot:latest \
            timeout 6 tcpdump -l -n -v -Q out -c 1 -i $2 "ip6 and dst net fcbb:bb00::/32 and not dst net fcbb:bb00:$3::/48" > $T/$1-$2.txt 2>/dev/null || true; }
  cap leaf1 eth0 1 & cap leaf1 eth1 1 & cap spine1 eth2 0 & cap spine2 eth2 0 &
  sleep 3
  c h1 ping -c 2 -i 0.2 -m 1 172.16.3.10 >/dev/null; c h1 ping -c 2 -i 0.2 -m 2 172.16.3.10 >/dev/null
  wait
  for f in "leaf1-eth0 h1 -> spine1 (leaving leaf1)" "spine1-eth2 spine1 -> leaf3 (after spine1 punched 100)" \
           "leaf1-eth1 h1 -> spine2 (leaving leaf1)" "spine2-eth2 spine2 -> leaf3 (after spine2 punched 200)"; do
    local x=$T/${f%% *}.txt
    if [ ! -s $x ]; then echo "--- ${f#* }: nothing captured"; continue; fi
    printf -- '--- %s\n    dst %-24s | SRH: %s segment[0]=%s | IPv6 payload %s bytes | inside: %s\n' "${f#* }" \
      "$(grep -Eo '> fcbb[0-9a-f:]+:' $x | head -1 | sed 's/^> //; s/:$//')" \
      "$(grep -Eo 'segleft=[0-9]+' $x | head -1 || echo none)" "$(grep -Eo '\[0\][0-9a-f:]+' $x | head -1 | sed 's/^\[0\]//')" \
      "$(grep -Eo 'payload length:? [0-9]+' $x | head -1 | grep -Eo '[0-9]+$')" "$(grep -Eo '[0-9.]+ > [0-9.]+: ICMP echo request' $x | head -1)"
  done
  rm -rf "$T"
  echo "Read it: the destination address IS the path (block fcbb:bb00, then spine, then leaf3, then fe00 = decap)."
  echo "Each spine shifts its own 16 bits off the front; the SRH segment [0] still shows what h1 originally wrote."
}

case "${1:-}" in
  up)
    containerlab deploy -t srv6.clab.yml
    echo "waiting until h1 reaches h3 on both planes (up to 90 s)..."
    wait_ready 90
    check
    ;;
  down)
    containerlab destroy -t srv6.clab.yml --cleanup || true
    rm -f "${SNAP_DIR:-/tmp}"/srv6-fail-*.txt
    ;;
  check) check ;;
  agent) agent "${2:-}" ;;
  link)
    case "${2:-}" in suspend|resume) link "$2" "${3:-}" ;; *) echo "usage: $0 link suspend|resume [\"nodeA:ethX nodeB:ethY\"]"; exit 1 ;; esac
    ;;
  fail)
    MODE=${2:-both}; HOLD=${3:-10}
    case $MODE in off|on) failtest $MODE $HOLD ;; both) failtest off $HOLD; failtest on $HOLD ;; *) echo "usage: $0 fail [off|on|both] [HOLD]"; exit 1 ;; esac
    echo "Compare: episode 2's eBGP twin lost 6-9 s on this same link (hold timer 9 s)."
    ;;
  xray) xray ;;
  *)
    sed -n '2,12p' "$0" | sed 's/^# \{0,1\}//'
    exit 1
    ;;
esac
