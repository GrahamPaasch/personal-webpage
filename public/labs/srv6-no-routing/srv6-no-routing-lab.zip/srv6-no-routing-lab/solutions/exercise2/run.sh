#!/usr/bin/env bash
# Exercise 2: who notices a dead spine1 <-> leaf3 link?  (spine1 eth2 <-> leaf3 eth0)
# Starts the host agents, breaks that link for 4 s, prints every host's agent log, repairs, stops the agents.
set -euo pipefail; cd "$(dirname "$(readlink -f "$0")")/../.."
[ "$(id -u)" -eq 0 ] || { echo "run with sudo"; exit 1; }
./lab.sh agent start
docker exec clab-srv6-h1 ping -n -q -i 0.01 -c 400 -m 1 172.16.2.10 > /tmp/srv6-ex2-h1h2.txt 2>&1 &
sleep 0.5
./lab.sh link suspend "spine1:eth2 leaf3:eth0"
sleep 3
./lab.sh link resume "spine1:eth2 leaf3:eth0"
wait
sleep 1
for h in h1 h2 h3; do
  echo "== $h"; docker exec clab-srv6-$h sh -c 'grep -E "DOWN|UP" /run/path-agent/log || echo "   (nothing: this host never noticed)"'
done
echo "== h1 -> h2 pinned to spine1 the whole time (never touches leaf3):"
grep -E 'packets transmitted' /tmp/srv6-ex2-h1h2.txt; rm -f /tmp/srv6-ex2-h1h2.txt
./lab.sh agent stop
