#!/usr/bin/env bash
# Exercise 3: drop the header. Switch h1's plane-1 route to h3 to "mode encap.red" (reduced SRH) and capture.
set -euo pipefail; cd "$(dirname "$(readlink -f "$0")")/../.."
[ "$(id -u)" -eq 0 ] || { echo "run with sudo"; exit 1; }
H1=clab-srv6-h1
cap() { # $1 label
  local T; T=$(mktemp)
  docker run --rm --net container:clab-srv6-leaf1 nicolaka/netshoot:latest timeout 6 tcpdump -l -n -v -Q out -c 1 -i eth0 \
    'ip6 and dst net fcbb:bb00:100::/48' > $T 2>/dev/null &
  sleep 3; docker exec $H1 ping -n -c 3 -i 0.2 -m 1 172.16.3.10 | grep -E 'packets transmitted'; wait
  echo "  $1: $(grep -Eo 'next-header [A-Za-z]+ \([0-9]+\), payload length:? [0-9]+' $T | head -1) | SRH: $(grep -Eo 'RT6 \([^)]*\)' $T | head -1 || echo 'none')"
  rm -f $T
}
echo "route now: $(docker exec $H1 ip route show 172.16.3.0/24 table 1)"; cap "mode encap    "
docker exec $H1 ip route replace 172.16.3.0/24 table 1 encap seg6 mode encap.red segs fcbb:bb00:100:3:fe00:: dev eth0
echo "route now: $(docker exec $H1 ip route show 172.16.3.0/24 table 1)"; cap "mode encap.red"
docker exec $H1 env SETUP_ONLY=1 bash /root/path-agent.sh 1 2 3
echo "restored h1's routes (SETUP_ONLY)"
