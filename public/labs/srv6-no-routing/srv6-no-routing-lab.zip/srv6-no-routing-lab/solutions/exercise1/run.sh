#!/usr/bin/env bash
# Exercise 1: add a third stop. Send h1 -> h3 through leaf1's OWN uN first: fcbb:bb00:1:100:3:fe00::
# Uses a scratch table (50) + fwmark 50 so the lab's normal routes are untouched; cleans up after itself.
set -euo pipefail; cd "$(dirname "$(readlink -f "$0")")/../.."
[ "$(id -u)" -eq 0 ] || { echo "run with sudo"; exit 1; }
H1=clab-srv6-h1; P=fcbb:bb00:1:100:3:fe00::
docker exec $H1 ip route replace 172.16.3.0/24 table 50 encap seg6 mode encap segs $P dev eth0
docker exec $H1 sh -c 'ip rule del pref 150 2>/dev/null; ip rule add pref 150 fwmark 50 lookup 50'
echo "h1 route (table 50): $(docker exec $H1 ip route show 172.16.3.0/24 table 50)"
T=$(mktemp -d)
for e in "h1 eth0 out" "leaf1 eth0 out"; do set -- $e
  docker run --rm --net container:clab-srv6-$1 nicolaka/netshoot:latest timeout 6 tcpdump -l -n -v -Q $3 -c 1 -i $2 \
    'ip6 and dst net fcbb:bb00::/32' > $T/$1.txt 2>/dev/null &
done
sleep 3
docker exec $H1 ping -n -c 5 -i 0.2 -m 50 172.16.3.10 | tail -2
wait
echo "dst leaving h1 (what h1 wrote):      $(grep -Eo '> fcbb[0-9a-f:]+:' $T/h1.txt | head -1 | sed 's/^> //; s/:$//')"
echo "dst leaving leaf1 towards spine1:    $(grep -Eo '> fcbb[0-9a-f:]+:' $T/leaf1.txt | head -1 | sed 's/^> //; s/:$//')   <- leaf1 punched its own '1'"
rm -rf $T
docker exec $H1 sh -c 'ip rule del pref 150; ip route flush table 50'
echo "cleaned up (table 50 + rule removed)"
