#!/bin/sh
# /etc/frr/srv6.sh <node-usid> [leaf-number]   spine1: srv6.sh 100   spine2: srv6.sh 200   leafN: srv6.sh N N
# Forwarding + SRv6 SIDs in the kernel. containerlab runs it once per switch after the links are wired
# (the exec step in srv6.clab.yml). It is kernel state: re-run it if you restart a switch container.
U=$1; L=$2
sysctl -qw net.ipv4.ip_forward=1
sysctl -qw net.ipv6.conf.all.forwarding=1
for i in all default eth0 eth1 eth2; do                 # Docker often starts containers with IPv6 off
  [ -e /proc/sys/net/ipv6/conf/$i ] && echo 0 > /proc/sys/net/ipv6/conf/$i/disable_ipv6
  [ -e /proc/sys/net/ipv6/conf/$i ] && echo 1 > /proc/sys/net/ipv6/conf/$i/seg6_enabled
done
ip link add sr0 type dummy 2>/dev/null; ip link set sr0 up      # SIDs MUST hang off a dummy, NOT lo (lo = silent drop)
# uN: "my 16 bits are first in the address -> shift them out, forward on the next uSID"
ip -6 route replace fcbb:bb00:$U::/48 encap seg6local action End flavors next-csid lblen 32 nflen 16 dev sr0
# leaves only: uDX4 decap function fe00 -> strip the IPv6 outer header, hand the IPv4 packet to the host
[ -n "$L" ] && ip -6 route replace fcbb:bb00:$L:fe00::/64 encap seg6local action End.DX4 nh4 172.16.$L.10 dev eth2
exit 0
