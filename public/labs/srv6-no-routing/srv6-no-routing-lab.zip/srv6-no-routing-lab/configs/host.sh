#!/bin/bash
# /root/host.sh ME REMOTE...   h1: host.sh 1 2 3   h2: host.sh 2 1 3   h3: host.sh 3 1 2
# Runs once on every host when containerlab builds the lab (exec step in srv6.clab.yml):
# addresses, the IPv6 gateway (the only "route" a host needs to reach the fabric), then the path agent's
# routes and rules WITHOUT starting its probe loop (SETUP_ONLY=1). Start the agent later: sudo ./lab.sh agent start
ME=$1; shift
sysctl -qw net.ipv6.conf.all.disable_ipv6=0 net.ipv6.conf.default.disable_ipv6=0 net.ipv6.conf.eth0.disable_ipv6=0
sysctl -qw net.ipv6.conf.eth0.accept_dad=0
ip addr replace 172.16.$ME.10/24 dev eth0
ip -6 addr replace fd00:a:$ME::10/64 dev eth0
ip -6 route replace default via fd00:a:$ME::1 dev eth0
SETUP_ONLY=1 bash /root/path-agent.sh $ME "$@"
