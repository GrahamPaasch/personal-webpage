#!/bin/bash
# path-agent.sh ME REMOTE...   e.g. on h1: path-agent.sh 1 2 3
# Host-side SRv6 path choice (MRC-style, simplified). Two planes: 1 = via spine1, 2 = via spine2.
# Switches run NO routing protocol; this script is the only thing that reacts to a broken path.
ME=$1; shift; REMOTES="$@"; DEV=eth0
MISS=${MISS:-3}; HEAL=${HEAL:-50}; INT=${INT:-0.01}     # 3 missed probes @10 ms = fail; 50 good = restore
S=/run/path-agent; mkdir -p $S
sid(){ echo "fcbb:bb00:${1}00:$2:fe00::"; }          # plane P, dest leaf L -> uSID carrier
enc(){ echo "encap seg6 mode encap segs $(sid $1 $2) dev $DEV"; }
log(){ local t=$EPOCHREALTIME ts; printf -v ts '%(%T)T' "${t%.*}"; t=${t#*.}   # ms timestamps (UTC), no GNU date needed
  echo "$ts.${t:0:3} $*" | tee -a $S/log; }
spray(){ local L=$1 P Q up nh   # main table: ECMP over every plane that is up (locals: callers loop on L and P)
  up=""; for P in 1 2; do [ "$(cat $S/$L.$P)" = up ] && up="$up $P"; done
  [ -z "$up" ] && return
  nh=""; for P in $up; do nh="$nh nexthop $(enc $P $L)"; done
  ip route replace 172.16.$L.0/24 $nh
  for P in 1 2; do Q=$P; [ "$(cat $S/$L.$P)" = up ] || Q=${up# }; Q=${Q%% *}
    ip route replace 172.16.$L.0/24 table $P $(enc $Q $L); done; }
# setup
sysctl -qw net.ipv4.fib_multipath_hash_policy=1
for P in 1 2; do
  ip addr replace 172.16.$ME.10$P/32 dev $DEV                  # probe target alias for plane P
  ip rule del pref 10$P 2>/dev/null; ip rule add pref 10$P from 172.16.$ME.10$P lookup 1$P   # reply on same plane
  ip rule del pref 11$P 2>/dev/null; ip rule add pref 11$P fwmark 1$P lookup 1$P            # probes: fixed plane
  ip rule del pref 12$P 2>/dev/null; ip rule add pref 12$P fwmark $P lookup $P              # pinned data: plane P (fails over)
done
for L in $REMOTES; do for P in 1 2; do echo up > $S/$L.$P; ip route replace 172.16.$L.0/24 table 1$P $(enc $P $L); done; spray $L; done
[ -n "$SETUP_ONLY" ] && exit 0
# probe loop: one ping per (dest leaf, plane), 100/s, -O prints "no answer yet" for each miss
for L in $REMOTES; do for P in 1 2; do (
  m=0; g=0
  ping -n -O -i $INT -m 1$P 172.16.$L.10$P 2>&1 | while read -r line; do
    case "$line" in
      *"no answer"*) g=0; m=$((m+1))
        if [ $m -eq $MISS ] && [ "$(cat $S/$L.$P)" = up ]; then echo down > $S/$L.$P; spray $L; log "leaf$L plane$P DOWN after $m misses -> moved to other plane"; fi ;;
      *"bytes from"*) m=0; g=$((g+1))
        if [ $g -eq $HEAL ] && [ "$(cat $S/$L.$P)" = down ]; then echo up > $S/$L.$P; spray $L; log "leaf$L plane$P UP -> spraying again"; fi ;;
    esac
  done ) & done; done
log "path-agent on h$ME: probing $(echo $REMOTES | wc -w) leaves x 2 planes every ${INT}s"
wait
