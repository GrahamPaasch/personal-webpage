#!/bin/sh
# Kernel settings every FRR node needs (both twins). Containerlab runs this at boot as an exec step.
sysctl -w net.ipv4.ip_forward=1
sysctl -w net.ipv6.conf.all.forwarding=1
sysctl -w net.ipv6.conf.all.disable_ipv6=0
sysctl -w net.ipv6.conf.default.disable_ipv6=0
# IPv6 must be on for BGP unnumbered (it peers over fe80:: link-local). Harmless for the OSPF twin.
for i in eth0 eth1 eth2 eth3; do [ -e /proc/sys/net/ipv6/conf/$i ] && sysctl -w net.ipv6.conf.$i.disable_ipv6=0; done
# Hash ECMP on L4 ports so parallel flows spread across both spines.
sysctl -w net.ipv4.fib_multipath_hash_policy=1
exit 0
