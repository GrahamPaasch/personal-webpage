#!/bin/sh
# Runs once on every router right after containerlab has wired the links (the exec step in *.clab.yml).
sh /etc/frr/sysctl.sh
# FRR starts before containerlab attaches the links. In that race bgpd's "import-check" (a `network`
# statement is only advertised while the prefix is really in the routing table) never registers with
# zebra, so shutting a host port would NOT withdraw its /24. Restarting bgpd once fixes it; watchfrr
# brings it straight back within a second or two. The OSPF twin has no `router bgp`, so nothing happens there.
if grep -q '^router bgp' /etc/frr/frr.conf; then
  sleep 1
  kill "$(pidof bgpd)" 2>/dev/null || true
fi
exit 0
