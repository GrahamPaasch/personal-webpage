#!/usr/bin/env python3
"""Per-router churn counters for the two twins (the table from episode 2).

usage:  sudo python3 scripts/count.py snap  bgp|ospf|both
        sudo python3 scripts/count.py diff  bgp|ospf|both
        sudo python3 scripts/count.py show  bgp|ospf|both     (absolute values, no snapshot needed)
        sudo python3 scripts/count.py quiet bgp|ospf|both     (wait until no counter moves for 10 s, max 120 s)

snap saves the current counters; diff prints them again with the change since the last snap in (+N).
Absolute numbers depend on how long the lab has been up and what you've done to it: always snap, then diff.

OSPF twin columns
  lsa_updates   new LSA instances this router has installed (sum of LSA sequence numbers above 0x80000000)
  lsdb_lsas     LSAs in the area-0 database (the whole map: one Router LSA per router)
  rib_routes    prefixes in the routing table (a COUNT: back to +0 once the link is back)
  spf_runs      how many times this router has run Dijkstra (SPF) over the whole map
BGP twin columns
  bgp_prefixes      prefixes in the BGP table
  bgp_updates_rcvd  BGP UPDATE messages received, all sessions
  bgp_updates_sent  BGP UPDATE messages sent, all sessions
  rib_routes        as above
"""
import json
import os
import re
import subprocess
import sys
import tempfile
import time

ROUTERS = ["spine1", "spine2", "leaf1", "leaf2", "leaf3"]
COLUMNS = {
    "ospf": ["lsa_updates", "lsdb_lsas", "rib_routes", "spf_runs"],
    "bgp": ["bgp_prefixes", "bgp_updates_rcvd", "bgp_updates_sent", "rib_routes"],
}
SNAP_DIR = os.environ.get("SNAP_DIR", tempfile.gettempdir())


def vtysh(twin, router, cmd, as_json=True):
    p = subprocess.run(["docker", "exec", f"clab-{twin}-{router}", "vtysh", "-c", cmd],
                       capture_output=True, text=True)
    if p.returncode:
        return None
    if not as_json:
        return p.stdout
    try:
        return json.loads(p.stdout or "{}")
    except ValueError:
        return {}


def router_counters(twin, r):
    d = {}
    if twin == "ospf":
        area = (vtysh(twin, r, "show ip ospf json") or {}).get("areas", {}).get("0.0.0.0", {})
        d["spf_runs"] = area.get("spfExecutedCounter", 0)
        d["lsdb_lsas"] = area.get("lsaNumber", 0)
        db = vtysh(twin, r, "show ip ospf database", as_json=False) or ""
        d["lsa_updates"] = sum(int(x, 16) - 0x80000000
                               for x in re.findall(r"^\S+\s+\S+\s+\d+\s+0x([0-9a-f]{8})", db, re.M))
    else:
        nbrs = vtysh(twin, r, "show bgp neighbors json") or {}
        stats = [n.get("messageStats", {}) for n in nbrs.values() if isinstance(n, dict)]
        d["bgp_updates_rcvd"] = sum(s.get("updatesRecv", 0) for s in stats)
        d["bgp_updates_sent"] = sum(s.get("updatesSent", 0) for s in stats)
        d["bgp_prefixes"] = len((vtysh(twin, r, "show ip bgp json") or {}).get("routes", {}))
    d["rib_routes"] = len(vtysh(twin, r, "show ip route json") or {})
    return d


def snapshot(twin):
    out = {}
    for r in ROUTERS:
        if vtysh(twin, r, "show version", as_json=False) is None:
            sys.exit(f"cannot reach clab-{twin}-{r}: is the lab up? (sudo ./lab.sh up)")
        out[r] = router_counters(twin, r)
    return out


def print_table(twin, now, old=None):
    cols = COLUMNS[twin]
    print("router  " + "  ".join(f"{k:>18}" for k in cols))
    for r in ROUTERS:
        cells = []
        for k in cols:
            v = now[r].get(k, 0)
            if old is None:
                cells.append(f"{v:>18}")
            else:
                cells.append(f"{v!s:>10} ({v - old.get(r, {}).get(k, 0):+d})".rjust(18))
        print(f"{r:7} " + "  ".join(cells))
    if old is None:
        return
    delta = {k: {r: now[r].get(k, 0) - old.get(r, {}).get(k, 0) for r in ROUTERS} for k in cols}
    if twin == "ospf":
        spf = delta["spf_runs"]
        print(f"=> OSPF: {sum(spf.values())} SPF runs on {sum(1 for v in spf.values() if v > 0)}/5 routers; "
              f"lsa_updates +{min(delta['lsa_updates'].values())}..+{max(delta['lsa_updates'].values())} per router")
    else:
        sent, rcvd = delta["bgp_updates_sent"], delta["bgp_updates_rcvd"]
        print(f"=> BGP: 0 SPF runs (BGP has no SPF); {sum(sent.values())} UPDATEs sent, {sum(rcvd.values())} received; "
              f"spine1 sent {sent['spine1']}")


def main():
    if len(sys.argv) != 3 or sys.argv[1] not in ("snap", "diff", "show", "quiet") or sys.argv[2] not in ("bgp", "ospf", "both"):
        sys.exit(__doc__)
    mode, which = sys.argv[1], sys.argv[2]
    if mode == "quiet":  # a freshly built lab is still re-originating LSAs; don't start a count mid-churn
        twins = ["ospf", "bgp"] if which == "both" else [which]
        prev, start = None, time.time()
        while time.time() - start < 120:
            cur = [snapshot(t) for t in twins]
            if cur == prev:
                print(f"counters quiet ({int(time.time() - start)} s)")
                return
            prev = cur
            time.sleep(10)
        print("counters still moving after 120 s; counting anyway")
        return
    for twin in (["ospf", "bgp"] if which == "both" else [which]):
        path = os.path.join(SNAP_DIR, f"bgp-vs-ospf-{twin}.json")
        now = snapshot(twin)
        if mode == "snap":
            with open(path, "w") as f:
                json.dump(now, f)
            print(f"{twin}: snapshot saved ({path})")
        elif mode == "show":
            print(f"--- {twin.upper()} twin (absolute)")
            print_table(twin, now)
        else:
            if not os.path.exists(path):
                sys.exit(f"no snapshot for {twin}: run  scripts/count.py snap {which}  first")
            with open(path) as f:
                old = json.load(f)
            print(f"--- {twin.upper()} twin (change since snap)")
            print_table(twin, now, old)


if __name__ == "__main__":
    main()
