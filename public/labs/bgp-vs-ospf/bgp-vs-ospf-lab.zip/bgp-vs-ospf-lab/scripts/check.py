#!/usr/bin/env python3
"""Health check for the twins: adjacencies, ECMP on every leaf, host ping mesh.

usage:  sudo python3 scripts/check.py bgp|ospf|both [--wait SECONDS]
--wait keeps re-checking until everything passes or the time runs out (used by lab.sh up).
Exit code 0 = all good.
"""
import json
import subprocess
import sys
import time

SPINES, LEAVES = ["spine1", "spine2"], ["leaf1", "leaf2", "leaf3"]
HOST_NET = {"leaf1": "172.16.1.0/24", "leaf2": "172.16.2.0/24", "leaf3": "172.16.3.0/24"}


def dx(container, *cmd):
    return subprocess.run(["docker", "exec", container, *cmd], capture_output=True, text=True)


def vjson(twin, r, cmd):
    p = dx(f"clab-{twin}-{r}", "vtysh", "-c", cmd)
    try:
        return json.loads(p.stdout or "{}")
    except ValueError:
        return {}


def adjacencies(twin, r):
    if twin == "ospf":
        nb = vjson(twin, r, "show ip ospf neighbor json").get("neighbors", {})
        return sum(1 for lst in nb.values() for n in (lst if isinstance(lst, list) else [lst])
                   if str(n.get("nbrState", n.get("state", ""))).startswith("Full"))
    peers = vjson(twin, r, "show bgp ipv4 unicast summary json").get("peers", {})
    return sum(1 for p in peers.values() if p.get("state") == "Established")


def ecmp(twin, leaf, prefix):
    routes = vjson(twin, leaf, f"show ip route {prefix} json").get(prefix, [])
    best = [x for x in routes if x.get("selected")]
    return sum(1 for nh in (best[0].get("nexthops", []) if best else []) if nh.get("fib"))


def ping(twin, src, dst):
    p = dx(f"clab-{twin}-h{src}", "ping", "-c", "3", "-i", "0.2", "-W", "1", f"172.16.{dst}.10")
    return p.returncode == 0


def check(twin, verbose):
    ok, lines = True, []
    adj = {r: adjacencies(twin, r) for r in SPINES + LEAVES}
    want = {r: (3 if r in SPINES else 2) for r in adj}
    total = sum(adj.values())
    good = all(adj[r] == want[r] for r in adj)
    ok &= good
    word = "Full" if twin == "ospf" else "Established"
    lines.append(f"  {'PASS' if good else 'FAIL'} {word}: {total}/12  " + " ".join(f"{r}={adj[r]}" for r in adj))
    for leaf in LEAVES:
        targets = [HOST_NET[l] for l in LEAVES if l != leaf] + [f"10.0.1.{l[-1]}/32" for l in LEAVES if l != leaf]
        counts = {t: ecmp(twin, leaf, t) for t in targets}
        good = all(c == 2 for c in counts.values())
        ok &= good
        lines.append(f"  {'PASS' if good else 'FAIL'} ECMP {leaf}: " + " ".join(f"{t}={c}" for t, c in counts.items()))
    pairs = [(s, d) for s in (1, 2, 3) for d in (1, 2, 3) if s != d]
    res = {(s, d): ping(twin, s, d) for s, d in pairs}
    good = all(res.values())
    ok &= good
    lines.append(f"  {'PASS' if good else 'FAIL'} ping mesh: {sum(res.values())}/6 pairs ok"
                 + ("" if good else "  failed: " + " ".join(f"h{s}->h{d}" for (s, d), v in res.items() if not v)))
    if verbose:
        print(f"[{twin.upper()} twin]")
        print("\n".join(lines))
    return ok


def main():
    args = sys.argv[1:]
    if not args or args[0] not in ("bgp", "ospf", "both"):
        sys.exit(__doc__)
    twins = ["bgp", "ospf"] if args[0] == "both" else [args[0]]
    wait = int(args[args.index("--wait") + 1]) if "--wait" in args else 0
    deadline = time.time() + wait
    pending = list(twins)
    while pending and time.time() < deadline:
        pending = [t for t in pending if not check(t, False)]
        if pending:
            time.sleep(5)
    results = [check(t, True) for t in twins]
    print("ALL CHECKS PASSED" if all(results) else "SOME CHECKS FAILED")
    sys.exit(0 if all(results) else 1)


if __name__ == "__main__":
    main()
