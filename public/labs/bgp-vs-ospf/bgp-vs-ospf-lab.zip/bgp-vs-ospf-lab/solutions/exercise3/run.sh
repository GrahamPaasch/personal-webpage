#!/bin/sh
# Exercise 3 answer, reproducible: stop spine2 carrying leaf1's traffic, without touching a link.
#   BGP:  per-prefix policy on spine2 only (episode 1's DRAIN pattern): prepend leaf1's prefixes towards
#         leaf2/leaf3, and prepend everything towards leaf1. Only paths via spine2 change; nobody runs SPF.
#   OSPF: the only knob is link cost. Raise the cost of link 2 on both ends -> new Router LSAs, flooded
#         everywhere, every router re-runs SPF.
# usage (from the kit folder):  sudo sh solutions/exercise3/run.sh
cd "$(dirname "$0")/../.." || exit 1
python3 scripts/count.py quiet both >/dev/null
python3 scripts/count.py snap both >/dev/null
docker exec clab-bgp-spine2 vtysh -c 'conf t' \
  -c 'ip prefix-list LEAF1 seq 5 permit 172.16.1.0/24' -c 'ip prefix-list LEAF1 seq 10 permit 10.0.1.1/32' \
  -c 'route-map DRAIN-LEAF1 permit 10' -c 'match ip address prefix-list LEAF1' -c 'set as-path prepend 65000 65000 65000' -c 'exit' \
  -c 'route-map DRAIN-LEAF1 permit 20' -c 'exit' \
  -c 'route-map PREPEND-ALL permit 10' -c 'set as-path prepend 65000 65000 65000' -c 'exit' \
  -c 'router bgp 65000' -c 'address-family ipv4 unicast' \
  -c 'neighbor eth0 route-map PREPEND-ALL out' -c 'neighbor eth1 route-map DRAIN-LEAF1 out' -c 'neighbor eth2 route-map DRAIN-LEAF1 out' \
  -c 'end'
docker exec clab-ospf-spine2 vtysh -c 'conf t' -c 'interface eth0' -c 'ip ospf cost 1000'
docker exec clab-ospf-leaf1  vtysh -c 'conf t' -c 'interface eth1' -c 'ip ospf cost 1000'
echo "$(date +%T) spine2 drained for leaf1 in both twins"; sleep 15
# (no "clear bgp soft out" needed: FRR re-sends to a peer by itself when its outbound route-map changes)
python3 scripts/count.py diff both
for t in ospf bgp; do
  echo "-- $t twin: leaf2 -> 172.16.1.0/24 (expect spine1 only)   |   leaf1 -> 172.16.3.0/24 (expect eth0 / spine1 only)"
  docker exec clab-$t-leaf2 vtysh -c 'show ip route 172.16.1.0/24' | grep '\*'
  docker exec clab-$t-leaf1 vtysh -c 'show ip route 172.16.3.0/24' | grep '\*'
done
docker exec clab-bgp-spine2 vtysh -c 'conf t' -c 'router bgp 65000' -c 'address-family ipv4 unicast' \
  -c 'no neighbor eth0 route-map PREPEND-ALL out' -c 'no neighbor eth1 route-map DRAIN-LEAF1 out' -c 'no neighbor eth2 route-map DRAIN-LEAF1 out' \
  -c 'end' -c 'conf t' -c 'no route-map DRAIN-LEAF1' -c 'no route-map PREPEND-ALL' -c 'no ip prefix-list LEAF1' -c 'end'
docker exec clab-ospf-spine2 vtysh -c 'conf t' -c 'interface eth0' -c 'no ip ospf cost'
docker exec clab-ospf-leaf1  vtysh -c 'conf t' -c 'interface eth1' -c 'no ip ospf cost'
echo "$(date +%T) drain removed in both twins"
