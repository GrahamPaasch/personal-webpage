#!/bin/sh
# Exercise 1 answer, reproducible: shut leaf3's host port (eth2) in BOTH twins, count, then undo.
# usage (from the kit folder):  sudo sh solutions/exercise1/run.sh
cd "$(dirname "$0")/../.." || exit 1
python3 scripts/count.py quiet both >/dev/null
python3 scripts/count.py snap both >/dev/null
for t in ospf bgp; do docker exec clab-$t-leaf3 vtysh -c 'conf t' -c 'interface eth2' -c 'shutdown'; done
echo "$(date +%T) leaf3 eth2 shut in both twins"; sleep 10
python3 scripts/count.py diff both
for t in ospf bgp; do echo "-- $t twin, leaf1: show ip route 172.16.3.0/24"; docker exec clab-$t-leaf1 vtysh -c 'show ip route 172.16.3.0/24' | head -1; done
for t in ospf bgp; do docker exec clab-$t-leaf3 vtysh -c 'conf t' -c 'interface eth2' -c 'no shutdown'; done
echo "$(date +%T) restored (no shutdown)"
