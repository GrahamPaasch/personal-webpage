#!/bin/sh
# Exercise 2 answer, reproducible: add loopback prefix 10.99.0.3/32 on leaf3 in BOTH twins, count, then undo.
# OSPF: lo is already in area 0, so the new address is advertised as soon as it exists.
# BGP: the address alone does nothing; BGP only advertises what you list, so add a network statement.
# usage (from the kit folder):  sudo sh solutions/exercise2/run.sh
cd "$(dirname "$0")/../.." || exit 1
python3 scripts/count.py quiet both >/dev/null
python3 scripts/count.py snap both >/dev/null
docker exec clab-ospf-leaf3 vtysh -c 'conf t' -c 'interface lo' -c 'ip address 10.99.0.3/32'
docker exec clab-bgp-leaf3 vtysh -c 'conf t' -c 'interface lo' -c 'ip address 10.99.0.3/32' \
  -c 'router bgp 65103' -c 'address-family ipv4 unicast' -c 'network 10.99.0.3/32'
echo "$(date +%T) 10.99.0.3/32 added on leaf3 in both twins"; sleep 10
python3 scripts/count.py diff both
for t in ospf bgp; do echo "-- $t twin, leaf1: show ip route 10.99.0.3/32"; docker exec clab-$t-leaf1 vtysh -c 'show ip route 10.99.0.3/32' | grep -E 'Known via|\*'; done
docker exec clab-ospf-leaf3 vtysh -c 'conf t' -c 'interface lo' -c 'no ip address 10.99.0.3/32'
docker exec clab-bgp-leaf3 vtysh -c 'conf t' -c 'router bgp 65103' -c 'address-family ipv4 unicast' -c 'no network 10.99.0.3/32' \
  -c 'exit' -c 'exit' -c 'interface lo' -c 'no ip address 10.99.0.3/32'
echo "$(date +%T) removed again"
