# BGP vs OSPF lab: "Why BGP? It's an app, not an IGP"

A free, self-hostable copy of the lab from episode 2 of Graham Paasch's series **"AI Agents Build the Lab"**.
The same small Clos fabric is built **twice**, side by side, from the same FRRouting 10.5.5 image with the
same cables and addresses. One twin runs **eBGP unnumbered** (episode 1's design), the other runs
**OSPFv2 unnumbered**. Then you break one link in both and count which routers have to do work.

Lesson (open in a browser): `lesson/index.html`
Online: https://www.grahampaasch.com/labs/bgp-vs-ospf (episode 1's lab: https://www.grahampaasch.com/labs/ai-fabric)

```
   each twin:  [spine1]          [spine2]          lo 10.0.0.1 / 10.0.0.2   (BGP twin: AS 65000)
               eth0 eth1 eth2    eth0 eth1 eth2
                |    |    |       |    |    |      fabric links: no IPv4 subnets (unnumbered)
               [leaf1] [leaf2] [leaf3]             eth0 -> spine1, eth1 -> spine2, eth2 -> host
                |       |       |                  lo 10.0.1.1-3            (BGP twin: AS 65101-65103)
               h1      h2      h3                  172.16.{1,2,3}.10/24, gateway .1 on the leaf

   "link 2" = leaf1 eth1 <-> spine2 eth0: the link the flap test breaks (in both twins at once)
```

## The three commands

```
sudo ./lab.sh up      # build BOTH twins (16 containers) and wait until healthy, ~1 minute
sudo ./lab.sh flap    # break link 2 in both twins for 20 s, then print who did work
sudo ./lab.sh down    # destroy both twins and clean up
```

`sudo make up` / `sudo make flap` / `sudo make down` do the same thing. Also: `sudo ./lab.sh check`
(adjacencies, ECMP, ping mesh) and `sudo ./lab.sh link suspend|resume` (break/repair link 2 by hand).

## What's in the kit

| Path | What |
|---|---|
| `lab.sh`, `Makefile` | up / check / flap / link / down for both twins |
| `bgp.clab.yml`, `ospf.clab.yml` | the two containerlab topologies (lab names `bgp` and `ospf`) |
| `configs/bgp/*.frr.conf` | eBGP unnumbered twin: episode 1's configs, unchanged |
| `configs/ospf/*.frr.conf` | OSPFv2 unnumbered twin: p2p links borrowing the loopback /32, hello 3 / dead 9 |
| `configs/common/` | FRR `daemons` (bgpd + ospfd + bfdd on in both twins), `vtysh.conf`, `sysctl.sh`, `boot.sh` |
| `scripts/count.py` | the per-router counter table from the video (SPF runs, LSA updates, BGP UPDATEs) |
| `scripts/check.py` | health check: 12/12 Full or Established, 2 ECMP next hops on every leaf, host ping mesh |
| `solutions/exercise{1,2,3}/` | `answer.txt` + `run.sh` that reproduces each answer and then undoes it |
| `lesson/index.html` | the full lesson, with the numbers measured on camera |

## Requirements

- Linux with Docker (tested on Ubuntu 24.04, x86_64). containerlab also runs under WSL2.
- [containerlab](https://containerlab.dev/install/) (tested with 0.73) and `python3` (3.8+, standard library only).
- **RAM:** 1 GB free is plenty. Measured: each FRR router about 30 MB, each host about 8 MB; 10 routers + 6 hosts is about 350 MB.
- **CPU:** 2 cores. Everything idles near zero.
- **Disk:** about 850 MB for the two images: `quay.io/frrouting/frr:10.5.5` (195 MB) and `nicolaka/netshoot` (630 MB).
  containerlab pulls them on the first `up`.
- Root (`sudo`), because containerlab and `docker exec` need it.

The topologies give containerlab's (unused) management bridges their own subnets, 172.31.251.0/24 and
172.31.252.0/24, so they don't collide with Docker's common 172.20.0.0/16. If those clash with something
on your machine, edit the `mgmt:` block at the top of `bgp.clab.yml` / `ospf.clab.yml`.

## Quickstart

```
$ unzip bgp-vs-ospf-lab.zip && cd bgp-vs-ospf-lab
$ sudo ./lab.sh up
...
[BGP twin]
  PASS Established: 12/12  spine1=3 spine2=3 leaf1=2 leaf2=2 leaf3=2
  PASS ECMP leaf1: 172.16.2.0/24=2 172.16.3.0/24=2 10.0.1.2/32=2 10.0.1.3/32=2
  ...
[OSPF twin]
  PASS Full: 12/12  spine1=3 spine2=3 leaf1=2 leaf2=2 leaf3=2
  ...
ALL CHECKS PASSED
```

Poke around:

```
docker exec -it clab-ospf-leaf1 vtysh      # OSPF twin router CLI:  show ip ospf neighbor / show ip ospf database
docker exec -it clab-bgp-leaf1 vtysh       # BGP twin router CLI:   show bgp summary / show ip route 172.16.3.0/24
docker exec -it clab-bgp-h1 bash           # a host shell (ping 172.16.3.10)
```

## The flap test

`sudo ./lab.sh flap` waits until all counters are quiet, snapshots both twins, starts pings (h1 to h2 and
h1 to h3, 10 per second, in both twins), breaks link 2 in both twins at the same moment for 20 s, repairs it,
waits 20 s, and prints the change on every router. "Break" means 100% packet loss on both ends with
`containerlab tools netem` while both interfaces stay **up**, like GNS3's *Suspend link* in the video: neither
protocol gets a "link down" hint, so both find out by their timers (OSPF dead 9 s, BGP hold 9 s).

What we measured **on camera** (GNS3, 10/18, 16:40):

```
router         lsa_updates           lsdb_lsas          rib_routes            spf_runs
spine1             88 (+4)              5 (+0)              8 (+0)             38 (+3)
spine2             88 (+4)              5 (+0)              8 (+0)             42 (+4)
leaf1              88 (+4)              5 (+0)              9 (+0)             44 (+4)
leaf2              88 (+4)              5 (+0)              9 (+0)             44 (+4)
leaf3              88 (+4)              5 (+0)              9 (+0)             38 (+4)
router        bgp_prefixes    bgp_updates_rcvd    bgp_updates_sent          rib_routes
spine1              7 (+0)             46 (+2)             24 (+0)              7 (+0)
spine2              7 (+0)             79 (+6)             78 (+9)              7 (+0)
leaf1               8 (+0)             45 (+5)             74 (+8)              9 (+0)
leaf2               8 (+0)             30 (+2)             30 (+0)              9 (+0)
leaf3               8 (+0)             30 (+2)             30 (+0)              9 (+0)
```

OSPF: 19 SPF runs across all 5 routers, and every router installed the same 4 new LSA versions.
BGP: no SPF anywhere (BGP doesn't have one), and spine1, which isn't on the broken link, sent nothing.
Our kit runs on containerlab reproduced this: the BGP deltas matched exactly every time, and OSPF gave 19 or 20
SPF runs on all 5 routers (spine1 +3 or +4: SPF throttling sometimes folds two LSA arrivals into one run) with +4
LSA updates on every router. Absolute values depend on how long the lab has been up; only the numbers in brackets
matter. Yours may differ slightly.

**Packet loss is about the same in both** (60 to 86 pings lost at 10 pps in the five GNS3 dry runs, either
protocol; 68 to 81 in our kit runs). Both wait for the same 9-second timer, and loss depends on where in the
3-second hello/keepalive cycle the break lands, so it varies run to run. Only a flow that hashes onto link 2
loses anything. **The win is blast radius and CPU work, not convergence speed.** Speed comes from BFD, in
either protocol (episode 1).

Reading the columns: `rib_routes` and `bgp_prefixes` are counts, so after the link comes back they read +0;
that doesn't mean nothing changed. `bgp_updates_rcvd` ticks on spine1 because the leaves re-advertise paths
like `65101 65000 65102`, which spine1 drops on sight (its own AS is already in the path).

You can also drive the counter by hand: `sudo python3 scripts/count.py snap both`, do something, then
`sudo python3 scripts/count.py diff both`.

## Exercises (answers in `solutions/` and in the lesson's "Answer" boxes)

1. **Where does the news go?** Shut leaf3's host port (`interface eth2` / `shutdown`) in both twins. Which
   routers re-run SPF? Which routers' tables change in the BGP twin, and did anyone recompute?
2. **Scale-out cost.** Add a loopback prefix 10.99.0.3/32 on leaf3 in both twins (BGP also needs
   `network 10.99.0.3/32`). Compare the diffs. What would a whole leaf4 cost each protocol?
3. **Policy is the app feature.** Make spine2 stop carrying traffic for leaf1 without touching a link.
   Can OSPF do it without every router re-running SPF?

Each `solutions/exerciseN/run.sh` applies the answer to both twins, prints the counter diff, and undoes it.

## Design notes

- **Fair fight:** same image, same node names, same 9 cables, same loopbacks and host subnets; hello 3 / dead 9
  in OSPF and keepalive 3 / hold 9 in BGP (`frr defaults datacenter`). Only the routing protocol differs.
- **Both twins are unnumbered.** BGP peers over IPv6 link-local (`neighbor eth0 interface`) and carries IPv4
  routes with an IPv6 next hop (RFC 8950). OSPF here is **OSPFv2, which is IPv4-only** (OSPFv3 is the IPv6
  version); each fabric interface borrows the router's loopback /32 with `ip ospf network point-to-point`,
  so routes show `via 10.0.0.1 dev eth0 onlink`. That's correct.
- **`boot.sh`** runs `sysctl.sh` (IP forwarding, IPv6 on for link-local, L4 ECMP hashing) and restarts bgpd
  once after the links exist. Without that restart, an FRR startup race in containers leaves bgpd's
  import-check unregistered and a shut host port would not withdraw its /24 (exercise 1 would lie).
- **Gotcha from the live build:** if you ever convert a running OSPF lab from /31s to unnumbered in place,
  `clear ip ospf neighbor` on the spines; FRR keeps a Full neighbor's old address. Always ping, don't trust
  "12/12 Full" alone.

## What was tested

containerlab 0.73 on Ubuntu 24.04, from this exact zip unzipped into a fresh folder: `up` passed every check
(BGP 12/12 Established, OSPF 12/12 Full, 2 ECMP next hops on every leaf to every remote host subnet and
loopback, 6/6 host ping pairs in each twin); `flap` printed the on-camera deltas above (OSPF 20 SPF runs that time, spine1 +4; BGP identical); all three exercise
scripts ran and restored the baseline; `down` removed every container, link and network.
The on-camera lab ran the same FRR configs in GNS3 2.2.56.

## Credits

- [FRRouting](https://frrouting.org), [containerlab](https://containerlab.dev), [netshoot](https://github.com/nicolaka/netshoot) hosts, [GNS3](https://gns3.com) (the lab in the video).
- [Agent Standup](https://github.com/Atoll92/agent-standup) by Atoll92: the live "video call" view of the
  Claude Code agent team that built and tested this lab on camera.
- The prompt: isaacyonemoto on Discord, "BGP is really only for network borders."
- References: RFC 7938 (BGP in large-scale data centers), RFC 8950 (IPv4 NLRI with IPv6 next hop),
  RFC 2328 (OSPFv2), RFC 5340 (OSPFv3), FRR docs (BGP unnumbered, OSPF point-to-point).
- How Graham runs his agent team: https://www.grahampaasch.com/cadence

## License

MIT for the kit (see `LICENSE`). Third-party software keeps its own license.
