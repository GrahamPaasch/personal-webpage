#!/usr/bin/env bash
# Episode 2 lab: the same 2-spine / 3-leaf / 3-host Clos twice, one eBGP, one OSPF.
#
#   sudo ./lab.sh up        build BOTH twins and wait until they are healthy (about 1 minute)
#   sudo ./lab.sh check     adjacencies 12/12, ECMP on every leaf, host ping mesh (both twins)
#   sudo ./lab.sh flap [N]  break leaf1<->spine2 in both twins for N seconds (default 20), print the counters
#   sudo ./lab.sh link suspend|resume   break / repair leaf1<->spine2 in both twins by hand
#   sudo ./lab.sh down      destroy both twins and clean up
#
# Needs: Linux, Docker, containerlab, python3. Run from anywhere; paths are relative to this file.
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
TWINS="bgp ospf"
SETTLE=20      # seconds to wait after the link comes back before counting
LEAD=5         # seconds of pings before the link breaks

[ "$(id -u)" -eq 0 ] || { echo "run with sudo (containerlab and docker need root): sudo $0 $*"; exit 1; }
for b in docker containerlab python3; do command -v $b >/dev/null || { echo "missing: $b (see README prerequisites)"; exit 1; }; done

link() { # suspend|resume : 100% loss on both ends of leaf1 eth1 <-> spine2 eth0, interfaces stay UP
  local loss word; [ "$1" = suspend ] && { loss=100; word=suspended; } || { loss=0; word=resumed; }
  for t in $TWINS; do
    containerlab tools netem set -n clab-$t-leaf1 -i eth1 --loss $loss >/dev/null &
    containerlab tools netem set -n clab-$t-spine2 -i eth0 --loss $loss >/dev/null &
  done
  wait
  echo "$(date +%T) link 2 (leaf1 eth1 <-> spine2 eth0) ${word} in both twins (loss ${loss}%, interfaces stay up)"
}

case "${1:-}" in
  up)
    for t in $TWINS; do containerlab deploy -t $t.clab.yml; done
    echo "waiting for OSPF Full / BGP Established, ECMP and pings (up to 120 s)..."
    python3 scripts/check.py both --wait 120
    ;;
  down)
    for t in $TWINS; do containerlab destroy -t $t.clab.yml --cleanup || true; done
    rm -f "${SNAP_DIR:-/tmp}"/bgp-vs-ospf-*.json
    ;;
  check)
    python3 scripts/check.py both
    ;;
  link)
    case "${2:-}" in suspend|resume) link "$2" ;; *) echo "usage: $0 link suspend|resume"; exit 1 ;; esac
    ;;
  flap)
    HOLD=${2:-20}
    N=$(( (LEAD + HOLD + SETTLE) * 10 ))
    TMP=$(mktemp -d)
    python3 scripts/count.py quiet both
    python3 scripts/count.py snap both
    echo "pinging h1->h2 and h1->h3 in both twins at 10 pps ($N each)..."
    for t in $TWINS; do for d in 2 3; do
      docker exec clab-$t-h1 ping -q -i 0.1 -W 1 -c $N 172.16.$d.10 > $TMP/$t-h$d.txt 2>&1 &
    done; done
    sleep $LEAD
    link suspend
    sleep "$HOLD"
    link resume
    echo "settling ${SETTLE}s..."
    sleep $SETTLE
    wait
    echo
    python3 scripts/count.py diff ospf
    python3 scripts/count.py diff bgp
    echo
    echo "ping loss during the flap (only a flow that hashes onto link 2 loses packets):"
    printf "%-8s %-12s %-12s\n" twin "h1->h2" "h1->h3"
    for t in ospf bgp; do
      row=""
      for d in 2 3; do
        s=$(grep -Eo '[0-9]+ packets transmitted, [0-9]+ (packets )?received' $TMP/$t-h$d.txt | head -1)
        tx=$(echo "$s" | awk '{print $1}'); rx=$(echo "$s" | awk '{print $4}')
        row="$row $(printf '%-12s' "$((tx - rx)) lost")"
      done
      printf "%-8s%s\n" $t "$row"
    done
    rm -rf "$TMP"
    ;;
  *)
    sed -n '2,12p' "$0" | sed 's/^# \{0,1\}//'
    exit 1
    ;;
esac
