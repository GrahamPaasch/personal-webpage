#!/usr/bin/env bash
# Bring every link of plane N back up.
set -euo pipefail
cd "$(dirname "$0")"; . lib/common.sh
P=${1:?usage: ./restore-plane.sh N}
t0=$(now)
plane_links "$P" all | while read -r node ifc; do nsip "$node" link set "$ifc" up; done
log_event "restore,$P,all,$t0"
echo "$(date +%T.%3N) plane $P UP"
