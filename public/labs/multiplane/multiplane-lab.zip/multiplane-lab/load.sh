#!/usr/bin/env bash
# All-planes load: g1->g3 and g2->g4, 64 TCP flows each, ECMP-hashed across every plane.
#   ./load.sh [SECONDS]   (default 60)     ./load.sh stop
# OUT=dir (under results/) switches to 100 ms JSON output for measure.sh.
cd "$(dirname "$0")"; . lib/common.sh
if [ "${1:-}" = stop ]; then for n in $(seq 1 "$GPUS"); do dx "g$n" pkill iperf3 2>/dev/null; done; echo "load stopped"; exit 0; fi
T=${1:-60}; FLOWS=${FLOWS:-64}
pairs="1:3 2:4"
for pr in $pairs; do s=${pr%:*}; d=${pr#*:}
  dx "g$d" pgrep -f "iperf3 -s" >/dev/null || dx "g$d" iperf3 -s -D
done
sleep 0.5
for pr in $pairs; do s=${pr%:*}; d=${pr#*:}
  if [ -n "${OUT:-}" ]; then
    docker exec -d "$PFX-g$s" sh -c "iperf3 -c 10.255.0.$d -B 10.255.0.$s -P $FLOWS -t $T -i 0.1 --json-stream --forceflush | python3 /lab/lib/stamp.py > /lab/results/$OUT/iperf-g$s.jsonl"
  else
    docker exec -d "$PFX-g$s" sh -c "iperf3 -c 10.255.0.$d -B 10.255.0.$s -P $FLOWS -t $T -i 1 --forceflush > /lab/results/load-g$s.txt 2>&1"
  fi
done
echo "load: g1->g3, g2->g4, $FLOWS flows each, ${T}s. Watch it: ./watch.sh   Stop: ./load.sh stop"
