#!/usr/bin/env bash
# Take plane N down: every link on its leaves and spine (GPU NICs lose carrier).
#   ./kill-plane.sh N           all links of plane N
#   ./kill-plane.sh N --gray    only leaf<->spine links: GPU NICs stay lit, plane silently black-holes
set -euo pipefail
cd "$(dirname "$0")"; . lib/common.sh
P=${1:?usage: ./kill-plane.sh N [--gray]}; scope=all; [ "${2:-}" = --gray ] && scope=gray
t0=$(now)
plane_links "$P" "$scope" | while read -r node ifc; do nsip "$node" link set "$ifc" down; done
log_event "kill,$P,$scope,$t0"
echo "$(date +%T.%3N) plane $P DOWN ($scope links)"
