#!/usr/bin/env bash
# How GPU hosts notice a dead plane. Static routes in every mode - no routing protocol anywhere.
#   bfd   : FRR static routes, one per plane, each tracked by multihop BFD (100 ms x 3) to the far GPU's NIC
#   probe : plain timeouts - a ping prober (1 s interval, 3 misses) rewrites the kernel ECMP route
#   none  : plain static ECMP route, nothing watches it
set -euo pipefail
cd "$(dirname "$0")"; . lib/common.sh
MODE=${1:?usage: ./detect.sh bfd|probe|none}
PROBE_INTERVAL=${PROBE_INTERVAL:-1}; PROBE_MISSES=${PROBE_MISSES:-3}
for n in $(seq 1 "$GPUS"); do
  dx "g$n" pkill -f probe.py 2>/dev/null || true
  add=(); del=(); nh=()
  for m in $(seq 1 "$GPUS"); do [ "$m" = "$n" ] && continue
    for p in $(seq 1 "$PLANES"); do
      add+=(-c "ip route 10.255.0.$m/32 10.$p.$m.2 bfd multi-hop source 10.$p.$n.2 profile fast")
      del+=(-c "no ip route 10.255.0.$m/32 10.$p.$m.2")
    done
  done
  if [ "$MODE" = bfd ]; then
    for m in $(seq 1 "$GPUS"); do dx "g$n" ip route del "10.255.0.$m/32" proto boot 2>/dev/null || true; done
    dx "g$n" vtysh -c "conf t" "${add[@]}" >/dev/null
  else
    dx "g$n" vtysh -c "conf t" "${del[@]}" >/dev/null 2>&1 || true
    if [ "$MODE" = probe ]; then
      dx "g$n" sh -c "nohup python3 /lab/lib/probe.py $n $GPUS $PLANES $PROBE_INTERVAL $PROBE_MISSES >/lab/results/probe-g$n.log 2>&1 &"
    else
      for m in $(seq 1 "$GPUS"); do [ "$m" = "$n" ] && continue
        nh=(); for p in $(seq 1 "$PLANES"); do nh+=(nexthop via "10.$p.$n.1" dev "eth$p"); done
        dx "g$n" ip route replace "10.255.0.$m/32" proto boot "${nh[@]}"
      done
    fi
  fi
done
echo "$MODE" > results/.mode
sleep 3
echo "detection mode: $MODE"
