#!/usr/bin/env bash
# One-screen view: detection mode, BFD sessions per plane, g1's ECMP route to g3.
cd "$(dirname "$0")"; . lib/common.sh
echo "mode: $(cat results/.mode 2>/dev/null)   $(cat results/.rate 2>/dev/null) per plane NIC   planes: $PLANES   GPUs: $GPUS"
echo "g1 -> g3 (10.255.0.3) next hops, one per live plane:"
dx g1 ip route show 10.255.0.3 | sed 's/^/  /'
if [ "$(cat results/.mode 2>/dev/null)" = bfd ]; then
  echo "g1 BFD sessions (up/total): $(dx g1 vtysh -c 'show bfd peers brief' | grep -c ' up ')/$(dx g1 vtysh -c 'show bfd peers brief' | grep -cE '^[0-9]')"
fi
