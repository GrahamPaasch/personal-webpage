#!/usr/bin/env bash
# One entry point:  ./lab.sh up | down | status | load [S] | watch | kill N [--gray] | restore N | detect MODE | measure [opts]
set -euo pipefail
cd "$(dirname "$0")"
need() { command -v "$1" >/dev/null 2>&1 || { echo "missing prerequisite: $1 ($2)"; exit 1; }; }
cmd=${1:-help}; [ $# -gt 0 ] && shift
case "$cmd" in
  up)      need docker "install Docker"; need containerlab "https://containerlab.dev/install/"; need python3 "apt install python3 python3-venv"
           chmod +x *.sh lib/py; exec ./up.sh "$@" ;;
  down)    exec ./down.sh "$@" ;;
  status)  exec ./status.sh "$@" ;;
  load)    exec ./load.sh "$@" ;;
  watch)   exec ./watch.sh "$@" ;;
  kill)    exec ./kill-plane.sh "$@" ;;
  restore) exec ./restore-plane.sh "$@" ;;
  detect)  exec ./detect.sh "$@" ;;
  measure) exec ./measure.sh "$@" ;;
  *) sed -n '2p' "$0"; echo "Needs: Linux, Docker, containerlab, sudo, python3 with venv, internet on first run (pulls the FRR image, pip installs matplotlib)."; echo "Quick start: ./lab.sh up && ./lab.sh status && ./lab.sh measure --mode bfd --gray"; exit 0 ;;
esac
