#!/usr/bin/env bash
# One recorded experiment: load on, kill a plane, restore, write CSVs + PNG.
#   ./measure.sh [--mode bfd|probe|none] [--plane N] [--gray] [--duration S] [--kill-at S] [--restore-at S]
# Output: results/<time>-<mode>-<scope>/{per_second.csv,per_100ms.csv,summary.txt,graph.png}; one line in results/summary.csv
set -euo pipefail
cd "$(dirname "$0")"; . lib/common.sh
MODE=bfd; PL=3; SCOPE=all; DUR=30; KILL=8; RESTORE=20
while [ $# -gt 0 ]; do case $1 in
  --mode) MODE=$2; shift;; --plane) PL=$2; shift;; --gray) SCOPE=gray;; --duration) DUR=$2; shift;;
  --kill-at) KILL=$2; shift;; --restore-at) RESTORE=$2; shift;; *) echo "unknown arg $1"; exit 1;; esac; shift; done
RUN=$(date +%Y%m%d-%H%M%S)-$MODE-$SCOPE; mkdir -p "results/$RUN"
./load.sh stop >/dev/null
[ "$(cat results/.mode 2>/dev/null)" = "$MODE" ] || ./detect.sh "$MODE"
pids=$(docker inspect -f '{{.State.Pid}}' $PFX-g3 $PFX-g4)
python3 lib/sampler.py "results/$RUN/rx.csv" "$((DUR + 3))" $pids &
docker exec -d $PFX-g1 sh -c "timeout $((DUR + 3)) ip monitor route nexthop | python3 /lab/lib/stamp.py > /lab/results/$RUN/routes-g1.log"
OUT=$RUN ./load.sh "$DUR" >/dev/null
t_start=$(now); echo "$t_start" > "results/$RUN/t_start"
echo "run $RUN: mode=$MODE plane=$PL scope=$SCOPE  kill@${KILL}s restore@${RESTORE}s of ${DUR}s"
sleep "$KILL";              ./kill-plane.sh "$PL" $([ $SCOPE = gray ] && echo --gray) | tee -a "results/$RUN/events.txt"
tail -1 results/events.csv > "results/$RUN/kill.csv"
sleep "$((RESTORE - KILL))"; ./restore-plane.sh "$PL" | tee -a "results/$RUN/events.txt"
tail -1 results/events.csv > "results/$RUN/restore.csv"
sleep "$((DUR - RESTORE + 3))"; wait
echo "$MODE,$PL,$SCOPE,$PLANES,$(cat results/.rate)" > "results/$RUN/meta.csv"
lib/py lib/analyze.py "results/$RUN"
