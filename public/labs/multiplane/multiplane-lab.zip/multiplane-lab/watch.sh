#!/usr/bin/env bash
# Live per-plane receive rate summed over the receiving GPUs (g3+g4), once a second. Ctrl-C to quit.
cd "$(dirname "$0")"; . lib/common.sh
exec python3 lib/watch.py "$PLANES" $(docker inspect -f '{{.State.Pid}}' $PFX-g3 $PFX-g4)
