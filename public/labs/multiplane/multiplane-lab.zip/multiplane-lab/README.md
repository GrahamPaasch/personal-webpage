# Multiplane lab: a software model of NVIDIA Spectrum-X Multiplane

Quick start (Linux, Docker, containerlab, sudo, python3-venv):

    ./lab.sh up                               # builds the multiplane/gpu image if missing, deploys, BFD on
    ./lab.sh status                           # 8 next hops, 24/24 BFD
    ./lab.sh measure --mode bfd --gray        # recorded run (30 s)
    ./lab.sh down                             # destroy it (28 containers: shut it down when you are done)

Every script below also works directly (`./up.sh`, `./kill-plane.sh 3 --gray` ...). `./lab.sh <name>` is the same thing.

Source: https://developer.nvidia.com/blog/giga-scale-ai-ethernet-evolution-spectrum-x-ethernet-rewrites-rules/

**What NVIDIA says:** each GPU's bandwidth is split across up to 8 independent two-tier planes.
That gets you more than 128k endpoints in two tiers, keeps about 90% of bandwidth with one of
8 planes down, and hides a link flap in 2.68 ms where software load balancing takes 1.08 s.

**What this lab is:** the same shape built from containers and Linux.
- 8 planes. Each plane is its own 2-tier fabric (`pN-leaf1`, `pN-leaf2`, `pN-spine`, FRR 10.5.5). It uses **static routes only**: no BGP, OSPF or any other routing protocol.
- 4 "GPU" hosts (`g1`..`g4`). Each has **one NIC per plane** (`ethN` goes to plane N) and the GPU address `10.255.0.N` on loopback.
- Traffic is spread over the planes by **Linux ECMP**: one static route per plane to each peer GPU, with a 5-tuple hash.
- Each plane NIC is shaped to **500 Mbit/s** (`RATE=` in up.sh), so one GPU = 8 x 500 Mbit = 4 Gbit/s.
- Three ways for a GPU to find out a plane is dead (`./detect.sh MODE`):
  - `bfd`: every per-plane static route is tracked by multihop BFD (100 ms x 3) to the far GPU's NIC on that plane.
  - `probe`: "plain timeouts". A ping prober (1 s interval, 3 misses) rewrites the ECMP route.
  - `none`: static ECMP and nothing watching it.

## Scripts
| | |
|---|---|
| `./up.sh` | deploy 28 containers, shape the NICs, turn on BFD detection (`MODE=probe ./up.sh` for the prober) |
| `./down.sh` | stop load, destroy the lab |
| `./status.sh` | detection mode, g1's ECMP next hops to g3, BFD sessions up |
| `./load.sh [S]` / `./load.sh stop` | iperf3 g1->g3 and g2->g4, 64 flows each (128 total), across all planes |
| `./watch.sh` | live per-plane Gbit/s at the receivers, once a second |
| `./kill-plane.sh N [--gray]` | plane N down. Default: every link (GPU NICs lose carrier). `--gray`: only leaf<->spine links, so GPU NICs stay lit and the plane silently black-holes |
| `./restore-plane.sh N` | every link of plane N back up |
| `./detect.sh bfd\|probe\|none` | switch detection live |
| `./measure.sh [--mode M] [--plane N] [--gray]` | recorded run: 30 s load, kill at 8 s, restore at 20 s. Writes `results/<run>/per_second.csv`, `per_100ms.csv`, `summary.txt`, `graph.png`, plus one line in `results/summary.csv` |

`gen.py` writes the topology and configs (`PLANES=4 python3 gen.py` for 4 planes, then `./down.sh && ./up.sh`).

## Measured on camera (8 planes, kill plane 3, gray failure, 128 flows)
| detection | failure | route fixed | stuck flows moving again | throughput kept |
|---|---|---|---|---|
| BFD 100 ms x 3 | gray (fabric links) | 0.165 s | **0.29 s** | 87.5% |
| ping timeouts 1 s x 3 | gray | 3.77 s | **6.69 s** | 87.5% |
| none | gray | never | **never** (until restore); 14 of 128 flows dead | 87.5% |
| none | all links (NIC loses carrier) | kernel, immediate | 0.21 s | 87.5% |

Your numbers will differ a little (a few flows, a few tens of ms). How to read it: aggregate throughput drops straight to 7/8
in every case, because the 7 surviving planes are already full. What detection changes is the **13-14 flows that were hashed onto
the dead plane** (earlier runs on this box hit 16-22). They sit at zero until the route is fixed, and then until TCP's next
retransmit timer fires. Backoff doubles each time (0.2, 0.4, 0.8, 1.6, 3.2 s), so 3.8 s of detection turned into 6.7 s of
stalled flows. In a collective (all-reduce), the step waits for its slowest flow.
The 200 ms minimum RTO is the Linux default and we left it alone on purpose: `ip route ... rto_min` can lower it per route (exercise).

## What a software lab can and can't show
- **Can:** the architecture (independent planes, NIC per plane, multipath across planes, no routing protocol), the 1/N bandwidth arithmetic (7/8 = 87.5%, close to NVIDIA's "about 90%"), and how much detection time matters, which we measure ourselves.
- **Can't:** NVIDIA's 2.68 ms. That number comes from SuperNIC hardware doing per-packet load balancing and failover. Here the NIC is a veth, failover is a kernel route change, and the recovery floor is TCP's 200 ms minimum RTO. We spread **flows**, not packets.
- Not real scale. 500 Mbit/s per plane, software forwarding, 4 hosts. 128k endpoints is a radix calculation, not something to demo.
- The "probe" mode stands in for "software load balancing". It is not NVIDIA's 1.08 s setup.

## 10-step run sheet
Run from the kit directory. Skip step 1 if `./status.sh` already shows 24/24 BFD.
1. `./up.sh`: 8 planes x 3 switches + 4 GPUs, static routes only.
2. `cat configs/p3-spine.frr.conf`: a whole plane's "routing" is 8 static routes. No BGP.
3. `./status.sh`: g1 reaches g3 over 8 next hops, one per plane, with 24/24 BFD sessions up.
4. Second terminal: `./watch.sh`. First terminal: `./load.sh 120`. 8 planes x 1 Gbit/s = 8 Gbit/s.
5. `./kill-plane.sh 3 --gray`: plane 3 drops to 0, total ~7.0 Gbit/s (87.5%). "NVIDIA says about 90% with 1 of 8 down."
6. `./restore-plane.sh 3`: back to 8 within about a second. Then `./load.sh stop`.
7. `./measure.sh --mode bfd --gray`: recorded run, then open `results/<run>/graph.png`. Point at "flows stuck" clearing in a fraction of a second (0.29 s on camera).
8. `./measure.sh --mode probe --gray`: same failure with plain timeouts. Point at the stair-step: 3.8 s detection becomes about 6.7 s because of TCP backoff.
9. `./measure.sh --mode none --gray`: static routes and no detection. Those flows never come back. Then `./detect.sh bfd`.
10. `column -s, -t results/summary.csv`: your numbers. NVIDIA's 2.68 ms vs 1.08 s is a different league (real hardware, real fabric): not a fair comparison with a container lab.

Each recorded run writes its own folder and graph under `results/`.
