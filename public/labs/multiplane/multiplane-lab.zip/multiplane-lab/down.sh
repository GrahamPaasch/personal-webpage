#!/usr/bin/env bash
# Stop load and destroy the lab.
cd "$(dirname "$0")"; . lib/common.sh
./load.sh stop 2>/dev/null || true
sudo containerlab destroy -t multiplane.clab.yml --cleanup
