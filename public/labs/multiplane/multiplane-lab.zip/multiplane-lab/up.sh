#!/usr/bin/env bash
# Build the GPU image if needed, deploy, shape each GPU NIC, enable BFD detection.
set -euo pipefail
cd "$(dirname "$0")"; . lib/common.sh
RATE=${RATE:-500mbit}          # per-plane NIC rate. 8 planes x 500 Mbit = 4 Gbit/s per "GPU".
docker image inspect multiplane/gpu:10.5.5 >/dev/null 2>&1 || docker build -t multiplane/gpu:10.5.5 -f Dockerfile.gpu .
mkdir -p results
sudo containerlab deploy -t multiplane.clab.yml --reconfigure
sleep 5
for n in $(seq 1 "$GPUS"); do for p in $(seq 1 "$PLANES"); do
  nsip "g$n" link set "eth$p" up
  sudo ip netns exec "$PFX-g$n" tc qdisc replace dev "eth$p" root tbf rate "$RATE" burst 256kb latency 50ms
done; done
echo "RATE=$RATE" > results/.rate
./detect.sh "${MODE:-bfd}"
./status.sh
