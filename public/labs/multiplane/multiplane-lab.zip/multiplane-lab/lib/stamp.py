"""Prefix each stdin line with the wall-clock time it arrived."""
import sys, time
for line in sys.stdin:
    sys.stdout.write(f"{time.time():.3f} {line}"); sys.stdout.flush()
