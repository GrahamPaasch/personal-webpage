# Sourced by every script. Paths, lab size, helpers.
LAB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
. "$LAB_DIR/lab.env"
PFX=clab-multiplane
dx() { local n=$1; shift; docker exec "$PFX-$n" "$@"; }          # run inside a node
nsip() { local n=$1; shift; sudo ip -n "$PFX-$n" "$@"; }          # fast: ip in node's netns
now() { date +%s.%N | cut -c1-14; }
log_event() { echo "$(now),$*" >> "$LAB_DIR/results/events.csv"; }
# Plane P switch links: "node iface" pairs. Gray failure = fabric links only (GPU NICs keep carrier).
plane_links() {
  local p=$1 scope=${2:-all} l h
  for l in $(seq 1 "$LEAVES"); do
    echo "p$p-leaf$l eth1"; echo "p$p-spine eth$l"
    if [ "$scope" = all ]; then for h in 2 3; do echo "p$p-leaf$l eth$h"; done; fi
  done
}
