"""Read per-interface rx bytes of a container from the host via /proc/<pid>/net/dev (no docker exec)."""
def rx(pid):
    out = {}
    with open(f"/proc/{pid}/net/dev") as f:
        for line in f.readlines()[2:]:
            name, data = line.split(":", 1)
            name = name.strip()
            if name.startswith("eth"):
                out[int(name[3:])] = int(data.split()[0])
    return out
