"""Turn one measure.sh run into per_100ms.csv, per_second.csv, summary.txt, graph.png."""
import sys, json, csv, pathlib, collections
run = pathlib.Path(sys.argv[1])
mode, plane, scope, planes, rate = (run / "meta.csv").read_text().strip().split(",")
plane, planes = int(plane), int(planes)
t_kill = float((run / "kill.csv").read_text().split(",")[0])
t_rest = float((run / "restore.csv").read_text().split(",")[0])
t0 = float((run / "t_start").read_text())

# --- throughput at the receivers, 100 ms bins ---
rows = collections.defaultdict(dict)
for r in csv.DictReader(open(run / "rx.csv")):
    rows[(r["t"], r["pid"])][int(r["plane"])] = int(r["rx_bytes"])
by_pid = collections.defaultdict(list)
for (t, pid), v in rows.items(): by_pid[pid].append((float(t), v))
bins = collections.defaultdict(lambda: [0.0] * (planes + 1))
for pid, samples in by_pid.items():
    samples.sort()
    for (ta, a), (tb, b) in zip(samples, samples[1:]):
        k = round((tb - t0) * 10) / 10
        for p in range(1, planes + 1):
            bins[k][p] += (b.get(p, 0) - a.get(p, 0)) * 8 / (tb - ta) / 1e9
ts = sorted(t for t in bins if 0 <= t)
# --- per-flow bytes from iperf3 (100 ms intervals, wall-clock stamped) ---
flow = collections.defaultdict(dict)          # (file, socket) -> {t: bytes}
for f in run.glob("iperf-*.jsonl"):
    for line in open(f):
        stamp, _, js = line.partition(" ")
        try: ev = json.loads(js)
        except ValueError: continue
        if ev.get("event") != "interval": continue
        k = round((float(stamp) - t0) * 10) / 10
        for st in ev["data"]["streams"]: flow[(f.name, st["socket"])][k] = st["bytes"]
# --- route change seen on g1 (detection) ---
det = None
for line in open(run / "routes-g1.log"):
    t = float(line.split(" ", 1)[0])
    if t >= t_kill - 0.001: det = t - t_kill; break
kill_s, rest_s = t_kill - t0, t_rest - t0
# The failure cohort: flows moving nothing 0.2-0.4 s after the kill (they were hashed onto the dead plane).
cohort = [k for k, v in flow.items() if any(v.get(t, 1) == 0 for t in v if kill_s + 0.2 <= t <= kill_s + 0.4)]
resume = {}
for k in cohort:
    later = [t for t, b in sorted(flow[k].items()) if t > kill_s + 0.2 and b > 0]
    resume[k] = later[0] if later and later[0] < rest_s else None
stuck = lambda t: sum(1 for k in cohort if t >= kill_s and (resume[k] is None or t < resume[k]) and t < rest_s)
stall = {t: stuck(t) for t in ts}
recovered = all(v is not None for v in resume.values())
recov = (max(resume.values()) - 0.1 - kill_s) if cohort and recovered else 0.0  # start of first non-zero interval
base_stall = 0
with open(run / "per_100ms.csv", "w") as f:
    w = csv.writer(f); w.writerow(["t_s", "total_gbps"] + [f"plane{p}_gbps" for p in range(1, planes + 1)] + ["flows_stuck_on_dead_plane"])
    for t in ts: w.writerow([t, round(sum(bins[t][1:]), 3)] + [round(x, 3) for x in bins[t][1:]] + [stall.get(t, 0)])
with open(run / "per_second.csv", "w") as f:
    w = csv.writer(f); w.writerow(["second", "total_gbps"] + [f"plane{p}_gbps" for p in range(1, planes + 1)] + ["flows_stuck_on_dead_plane", "event"])
    for s in range(int(ts[-1]) + 1):
        ks = [t for t in ts if s <= t < s + 1]
        if not ks: continue
        avg = [sum(bins[t][p] for t in ks) / len(ks) for p in range(planes + 1)]
        ev = ("kill plane %d" % plane if s <= kill_s < s + 1 else "") + ("restore" if s <= rest_s < s + 1 else "")
        w.writerow([s, round(sum(avg[1:]), 3)] + [round(x, 3) for x in avg[1:]] + [max(stall.get(t, 0) for t in ks), ev])
tot = lambda a, b: [sum(bins[t][1:]) for t in ts if a <= t < b]
mean = lambda x: sum(x) / len(x) if x else float("nan")
pre = mean(tot(kill_s - 5, kill_s))
steady = mean(tot(min(kill_s + max(recov, 1) + 0.5, rest_s - 1), rest_s))
dip = min(tot(kill_s, rest_s) or [float("nan")])
summary = {
  "mode": mode, "scope": scope, "plane_killed": plane, "planes": planes, "rate_per_plane": rate.replace("RATE=", ""),
  "detect_s": ("carrier" if scope == "all" else "none") if det is None or scope == "all" else round(det, 3),
  "flows_running_again_s": round(recov, 2) if recovered else f"never (>{rest_s - kill_s:.1f} until restore)",
  "pre_gbps": round(pre, 2), "worst_100ms_gbps": round(dip, 2), "after_gbps": round(steady, 2),
  "kept_pct": round(100 * steady / pre, 1), "ideal_pct": round(100 * (planes - 1) / planes, 1),
  "flows_on_dead_plane": len(cohort), "total_flows": len(flow),
}
(run / "summary.txt").write_text("\n".join(f"{k}: {v}" for k, v in summary.items()) + "\n")
print(open(run / "summary.txt").read())
sf = run.parent / "summary.csv"
new = not sf.exists()
with open(sf, "a") as f:
    w = csv.writer(f)
    if new: w.writerow(["run"] + list(summary))
    w.writerow([run.name] + list(summary.values()))
# --- graph ---
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
fig, (a1, a2) = plt.subplots(2, 1, figsize=(11, 6.2), sharex=True, gridspec_kw={"height_ratios": [3, 1]})
ys = [[bins[t][p] for t in ts] for p in range(1, planes + 1)]
a1.stackplot(ts, ys, colors=C[:planes], labels=[f"plane {p}" for p in range(1, planes + 1)], edgecolor="white", linewidth=0.6)
for a in (a1, a2):
    a.axvline(kill_s, color="#333", lw=1.2, ls="--"); a.axvline(rest_s, color="#333", lw=1.2, ls=":")
    for s in ("top", "right"): a.spines[s].set_visible(False)
    a.grid(axis="y", color="#e6e6e6", lw=0.8); a.set_axisbelow(True)
a1.text(kill_s + 0.2, pre * 1.04, f"plane {plane} down", fontsize=9, color="#333")
a1.text(rest_s + 0.2, pre * 1.04, "restored", fontsize=9, color="#333")
a1.set_ylim(0, pre * 1.15); a1.set_ylabel("Gbit/s received (g3+g4)")
fig.suptitle(f"{planes} planes, kill plane {plane} ({scope} links), detection = {mode}:  kept {summary['kept_pct']}% "
             f"(ideal {summary['ideal_pct']}%), flows moving again after {summary['flows_running_again_s']} s", fontsize=10, x=0.02, ha="left")
fig.legend(*a1.get_legend_handles_labels(), loc="upper center", bbox_to_anchor=(0.5, 0.93), ncol=planes, fontsize=8, frameon=False)
a2.plot(ts, [stall.get(t, 0) for t in ts], color="#2a78d6", lw=2)
a2.set_ylabel("flows stuck\n(dead plane)"); a2.set_xlabel("seconds")
fig.tight_layout(rect=(0, 0, 1, 0.9)); fig.savefig(run / "graph.png", dpi=130)
print(f"wrote {run}/graph.png")
