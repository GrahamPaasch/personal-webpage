"""Host-side 10 Hz sampler: rx bytes per plane NIC on the receiving GPUs. args: outfile seconds pid..."""
import sys, time, os
sys.path.insert(0, os.path.dirname(__file__))
from netdev import rx
out, dur, pids = sys.argv[1], float(sys.argv[2]), sys.argv[3:]
end = time.time() + dur
with open(out, "w") as f:
    f.write("t,pid,plane,rx_bytes\n")
    nxt = time.time()
    while time.time() < end:
        t = time.time()
        for pid in pids:
            for p, b in rx(pid).items():
                f.write(f"{t:.3f},{pid},{p},{b}\n")
        nxt += 0.1
        time.sleep(max(0, nxt - time.time()))
