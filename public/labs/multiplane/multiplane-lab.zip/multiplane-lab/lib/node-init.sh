#!/bin/sh
# Runs inside every node at deploy. Kernel knobs for routers and GPU hosts.
sysctl -qw net.ipv4.ip_forward=1
sysctl -qw net.ipv4.conf.all.rp_filter=0 net.ipv4.conf.default.rp_filter=0
# Skip ECMP nexthops whose NIC has lost carrier (the "local link down" case).
sysctl -qw net.ipv4.conf.all.ignore_routes_with_linkdown=1 net.ipv4.conf.default.ignore_routes_with_linkdown=1
# Hash ECMP on the 5-tuple so parallel flows spread across planes.
sysctl -qw net.ipv4.fib_multipath_hash_policy=1
for f in /proc/sys/net/ipv4/conf/eth*/rp_filter; do echo 0 > $f; done 2>/dev/null
for f in /proc/sys/net/ipv4/conf/eth*/ignore_routes_with_linkdown; do echo 1 > $f; done 2>/dev/null
exit 0
