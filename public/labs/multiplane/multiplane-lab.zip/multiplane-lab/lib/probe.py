"""'Plain timeouts' detector: ping the far GPU's NIC on every plane each interval;
after MISSES misses in a row drop that plane from the kernel ECMP route; one reply puts it back.
args: self_id gpus planes interval misses"""
import subprocess, sys, time
me, gpus, planes, interval, misses = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]), float(sys.argv[4]), int(sys.argv[5])
peers = [m for m in range(1, gpus + 1) if m != me]
miss = {(m, p): 0 for m in peers for p in range(1, planes + 1)}
installed = {}
def install(m, live):
    if not live: live = list(range(1, planes + 1))   # never leave a GPU with no route at all
    if installed.get(m) == live: return
    cmd = ["ip", "route", "replace", f"10.255.0.{m}/32", "proto", "boot"]
    for p in live: cmd += ["nexthop", "via", f"10.{p}.{me}.1", "dev", f"eth{p}"]
    subprocess.run(cmd, check=False); installed[m] = live
    print(f"{time.time():.3f} route 10.255.0.{m} planes={live}", flush=True)
for m in peers: install(m, list(range(1, planes + 1)))
while True:
    t0 = time.time()
    procs = {k: subprocess.Popen(["ping", "-n", "-q", "-c1", "-W", str(max(1, int(interval))), "-I", f"10.{k[1]}.{me}.2", f"10.{k[1]}.{k[0]}.2"],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) for k in miss}
    for k, pr in procs.items():
        miss[k] = 0 if pr.wait() == 0 else miss[k] + 1
    for m in peers:
        install(m, [p for p in range(1, planes + 1) if miss[(m, p)] < misses])
    time.sleep(max(0, interval - (time.time() - t0)))
