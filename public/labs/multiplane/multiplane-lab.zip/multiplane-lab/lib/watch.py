import sys, time
sys.path.insert(0, __import__("os").path.dirname(__file__))
from netdev import rx
planes = int(sys.argv[1]); pids = sys.argv[2:]
def snap():
    tot = {p: 0 for p in range(1, planes + 1)}
    for pid in pids:
        for p, b in rx(pid).items():
            if p in tot: tot[p] += b
    return time.time(), tot
t0, a = snap(); peak = 0
while True:
    time.sleep(1)
    t1, b = snap(); dt = t1 - t0
    rates = {p: (b[p] - a[p]) * 8 / dt / 1e9 for p in b}
    total = sum(rates.values()); peak = max(peak, total)
    bars = "  ".join(f"P{p}:{'#' * round(r * 5):<5}{r:4.2f}" for p, r in rates.items())
    pct = f"{100 * total / peak:5.1f}% of peak" if peak > 0.1 else ""
    print(f"{time.strftime('%T')}  total {total:5.2f} Gbit/s {pct}\n   {bars}", flush=True)
    t0, a = t1, b
